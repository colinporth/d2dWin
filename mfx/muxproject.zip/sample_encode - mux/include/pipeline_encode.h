//* ////////////////////////////////////////////////////////////////////////////// */
//*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
//*/

#ifndef __PIPELINE_ENCODE_H__
#define __PIPELINE_ENCODE_H__

#define D3D_SURFACES_SUPPORT

#ifdef D3D_SURFACES_SUPPORT
#pragma warning(disable : 4201)
#include <d3d9.h>
#include <dxva2api.h>
#endif

#include "sample_defs.h"
#include "sample_utils.h"
#include "base_allocator.h"

#include "mfxvideo.h"
#include "mfxvideo++.h"
#include "sample_plugin.h"

struct sInputParams
{
    mfxU16 nTargetUsage;
    mfxU32 CodecId;
    mfxU32 ColorFormat;
    mfxU16 nPicStruct;
    mfxU16 nWidth; // source picture width
    mfxU16 nHeight; // source picture height
    mfxF64 dFrameRate;
    mfxU16 nBitRate;
    mfxU8 nThreads;

    mfxU16 nDstWidth; // destination picture width, specified if resizing required
    mfxU16 nDstHeight; // destination picture height, specified if resizing required

    bool bd3dAlloc; // true - frames in video memory (d3d surfaces), false - in system memory
    bool bUseHWLib; // true if application wants to use HW mfx library

    TCHAR strSrcFile[MAX_FILENAME_LEN];
    TCHAR strDstFile[MAX_FILENAME_LEN];

    mfxU8 nRotationAngle; // if specified, enables custom rotation plugin in mfx pipeline
	bool bMux;
};

struct sTask
{
    mfxBitstream mfxBS;
    mfxSyncPoint EncSyncP;    
    std::list<mfxSyncPoint> DependentVppTasks;
};

class CEncTaskPool
{
public:
    CEncTaskPool();
    virtual ~CEncTaskPool();

    virtual mfxStatus Init(MFXVideoSession* pmfxSession, CSmplBitstreamWriter* pWriter, mfxU32 nPoolSize, mfxU32 nBufferSize);
    virtual mfxStatus GetFreeTask(sTask **ppTask);
    virtual mfxStatus SynchronizeFirstTask();      
    virtual void Close();     

protected:
    sTask* m_pTasks;
    mfxU32 m_nPoolSize;    
    mfxU32 m_nTaskBufferStart;

    MFXVideoSession* m_pmfxSession;
    CSmplBitstreamWriter* m_pWriter; 

    virtual mfxU32 GetFreeTaskIndex();    
};

/* This class implements a pipeline with 2 mfx components: vpp (video preprocessing) and encode */
class CEncodingPipeline
{
public:
    CEncodingPipeline();
    virtual ~CEncodingPipeline();

    virtual mfxStatus Init(sInputParams *pParams);
    virtual mfxStatus Run();
    virtual void Close();
    virtual mfxStatus ResetMFXComponents(sInputParams* pParams);
    virtual mfxStatus ResetDevice();

protected:
    CSmplBitstreamWriter *m_pFileWriter;
    CSmplYUVReader m_FileReader;  
    
    CEncTaskPool m_TaskPool; 
    mfxU16 m_nAsyncDepth; // depth of asynchronous pipeline, this number can be tuned to achieve better performance

    MFXVideoSession m_mfxSession;
    MFXVideoENCODE* m_pmfxENC;
    MFXVideoVPP* m_pmfxVPP;

    mfxVideoParam m_mfxEncParams; 
    mfxVideoParam m_mfxVppParams; 
    mfxExtBuffer** m_ppVppExtBuffers;
    mfxU16 m_nNumVppExtBuffers;
    
    MFXFrameAllocator* m_pMFXAllocator; 
    mfxAllocatorParams* m_pmfxAllocatorParams;
    bool m_bd3dAlloc; // use d3d surfaces
    bool m_bExternalAlloc; // use memory allocator as external for Media SDK

    mfxFrameSurface1* m_pEncSurfaces; // frames array for encoder input (vpp output)
    mfxFrameSurface1* m_pVppSurfaces; // frames array for vpp input
    mfxFrameAllocResponse m_EncResponse;  // memory allocation response for encoder  
    mfxFrameAllocResponse m_VppResponse;  // memory allocation response for vpp  

#ifdef D3D_SURFACES_SUPPORT
    IDirect3D9*              m_pd3d;
    IDirect3DDeviceManager9* m_pd3dDeviceManager; 
    IDirect3DDevice9* m_pd3dDevice;
    UINT m_resetToken;
#endif  

    virtual mfxStatus InitMfxEncParams(sInputParams *pParams);
    virtual mfxStatus InitMfxVppParams(sInputParams *pParams);
    virtual void InitVppExtParam();

    virtual mfxStatus CreateVppExtBuffers();    
    virtual void DeleteVppExtBuffers();

    virtual mfxStatus CreateAllocator();
    virtual void DeleteAllocator();    

    virtual mfxStatus CreateDeviceManager(); 
    virtual void DeleteDeviceManager();

    virtual mfxStatus AllocFrames();
    virtual void DeleteFrames();         
    
    virtual void  PrintInfo();
    virtual mfxStatus AllocateSufficientBuffer(mfxBitstream* pBS);
};

#endif // __PIPELINE_ENCODE_H__ 