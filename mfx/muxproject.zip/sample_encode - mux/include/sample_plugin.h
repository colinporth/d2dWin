//* ////////////////////////////////////////////////////////////////////////////// */
//*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
//*/

#ifndef __SAMPLE_PLUGIN_H__
#define __SAMPLE_PLUGIN_H__

#include <stdlib.h>
#include <memory.h>

#include "mfxplugin.h"
#include "sample_defs.h"

/* A class wrapper over mfxPlugin structure, implements callbacks as redirection to virtual methods,
which should be overridden in derived classes */
class MFXPlugin : public mfxPlugin
{
public:
    MFXPlugin();
    virtual ~MFXPlugin();      

protected: 
    virtual mfxStatus mfxPluginInit(mfxCoreInterface *core) = 0;
    virtual mfxStatus mfxPluginClose() = 0;
    virtual mfxStatus mfxGetPluginParam(mfxPluginParam *par) = 0;
    virtual mfxStatus mfxSubmit(const mfxHDL *in, mfxU32 in_num, const mfxHDL *out, mfxU32 out_num, mfxThreadTask *task) = 0;
    virtual mfxStatus mfxExecute(mfxThreadTask task, mfxU32 thread_id, mfxU32 call_count) = 0;
    virtual mfxStatus mfxFreeResources(mfxThreadTask task, mfxStatus sts) = 0;    

private:
    static mfxStatus PluginInit_(mfxHDL pthis, mfxCoreInterface *core);
    static mfxStatus PluginClose_(mfxHDL pthis);
    static mfxStatus GetPluginParam_(mfxHDL pthis, mfxPluginParam *par);
    static mfxStatus Submit_(mfxHDL pthis, const mfxHDL *in, mfxU32 in_num, const mfxHDL *out, mfxU32 out_num, mfxThreadTask *task);
    static mfxStatus Execute_(mfxHDL pthis, mfxThreadTask task, mfxU32 thread_id, mfxU32 call_count);
    static mfxStatus FreeResources_(mfxHDL pthis, mfxThreadTask task, mfxStatus sts);    
};

typedef struct {
    mfxU32 StartLine;
    mfxU32 EndLine;
} DataChunk;

class Processor
{
public:
    Processor();
    virtual ~Processor();

    virtual mfxStatus Init(mfxFrameSurface1 *frame_in, mfxFrameSurface1 *frame_out);
    virtual mfxStatus Process(DataChunk *chunk) = 0;

protected:
    mfxFrameSurface1 *m_pIn;
    mfxFrameSurface1 *m_pOut;
};

class Rotator180 : public Processor
{
public:
    Rotator180();
    virtual ~Rotator180();
    
    virtual mfxStatus Process(DataChunk *chunk);
};

struct RotateParam : mfxPluginParam {
    mfxFrameInfo In; // input frame info
    mfxFrameInfo Out; // output frame info
    mfxU8 Angle; // rotation angle
    mfxU32 MaxNumTasks; // maximum number of tasks that can be submitted without synchronization    
};

typedef struct {
    mfxFrameSurface1 *In;
    mfxFrameSurface1 *Out;
    bool bBusy;    
    Processor *pProcessor;    
} RotateTask;

class Rotate : public MFXPlugin
{
public:
    Rotate();
    virtual ~Rotate();      

    // methods to be called by Media SDK
    virtual mfxStatus mfxPluginInit(mfxCoreInterface *core);
    virtual mfxStatus mfxPluginClose();
    virtual mfxStatus mfxGetPluginParam(mfxPluginParam *par);
    virtual mfxStatus mfxSubmit(const mfxHDL *in, mfxU32 in_num, const mfxHDL *out, mfxU32 out_num, mfxThreadTask *task);
    virtual mfxStatus mfxExecute(mfxThreadTask task, mfxU32 thread_id, mfxU32 call_count);
    virtual mfxStatus mfxFreeResources(mfxThreadTask task, mfxStatus sts); 

    // methods to be called by application
    virtual mfxStatus Init(RotateParam *par);
    void Close();
    static mfxStatus GetOutputFrameSize(mfxU16 srcw, mfxU16 srch, mfxU32 angle, mfxU16 *dstw, mfxU16 *dsth);

protected:
    bool m_bInited;    

    mfxCoreInterface *m_pmfxCore;

    RotateParam m_Param;
    
    RotateTask *m_pTasks;  

    DataChunk *m_pChunks;

    mfxU32 m_NumChunks;

    mfxStatus CheckParam(RotateParam *pParam);
    mfxStatus CheckInOutFrameInfo(mfxFrameInfo *pIn, mfxFrameInfo *pOut);
    mfxStatus CheckFrameData(mfxFrameSurface1 * pSurface);
    mfxU32 FindFreeTaskIdx();
};

#endif __SAMPLE_PLUGIN_H__
