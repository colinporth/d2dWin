//* ////////////////////////////////////////////////////////////////////////////// */
//*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2010 Intel Corporation. All Rights Reserved.
//
//
//*/

#ifndef __PIPELINE_USER_H__
#define __PIPELINE_USER_H__

#include "pipeline_encode.h"

/* This class implements the following pipeline: user plugin (frame rotation) -> mfxENCODE */
class CUserPipeline : public CEncodingPipeline
{
public:

    CUserPipeline();
    virtual ~CUserPipeline();

    virtual mfxStatus Init(sInputParams *pParams);
    virtual mfxStatus Run();
    virtual void Close();
    virtual mfxStatus ResetMFXComponents(sInputParams* pParams);    

protected:        

    Rotate m_usrRotatePlugin;
    RotateParam m_usrRotateParams;
    mfxFrameSurface1* m_pRotateSurfaces; // frames array for rotate input 
    mfxFrameAllocResponse m_RotateResponse;  // memory allocation response for rotate plugin   
            
    virtual mfxStatus InitRotateParam(sInputParams *pParams);

    virtual mfxStatus AllocFrames();
    virtual void DeleteFrames();         
    
    virtual void  PrintInfo();       
};


#endif // __PIPELINE_USER_H__ 