//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2010 Intel Corporation. All Rights Reserved.
//
//
//*/

#include "pipeline_user.h"
#include "sysmem_allocator.h"

mfxStatus CUserPipeline::InitRotateParam(sInputParams *pInParams)
{
    CHECK_POINTER(pInParams, MFX_ERR_NULL_PTR);

    m_usrRotateParams.Angle = pInParams->nRotationAngle;
    m_usrRotateParams.ThreadPolicy = MFX_THREADPOLICY_PARALLEL; // allow inter-frame parallelization
    m_usrRotateParams.MaxNumTasks = 32; // the maximum number of tasks that can be submitted before any task execution finishes
    m_usrRotateParams.MaxThreadNum = MAX(pInParams->nThreads, 1);// the maximum number of concurrent threads allowed for task execution

    memcpy(&m_usrRotateParams.Out, &m_mfxEncParams.mfx.FrameInfo, sizeof(mfxFrameInfo));
    
    m_usrRotateParams.In.FourCC = MFX_FOURCC_NV12;        
    m_usrRotateParams.In.Width = m_usrRotateParams.In.CropW = pInParams->nWidth;  
    m_usrRotateParams.In.Height = m_usrRotateParams.In.CropH = pInParams->nHeight; 

    m_usrRotateParams.Out.FourCC = MFX_FOURCC_NV12;
    m_usrRotateParams.Out.Width = m_usrRotateParams.Out.CropW = pInParams->nWidth;  
    m_usrRotateParams.Out.Height = m_usrRotateParams.Out.CropH = pInParams->nHeight;
    
    return MFX_ERR_NONE;
}

mfxStatus CUserPipeline::AllocFrames()
{    
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;
    
    mfxFrameAllocRequest EncRequest, RotateRequest;
        
    mfxU16 nEncSurfNum = 0; // number of frames at encoder input (rotate output)    
    mfxU16 nRotateSurfNum = 0; // number of frames at rotate input        

    ZERO_MEMORY(EncRequest);        

    // calculate number of surfaces required for components in chain vpp1 - rotate - vpp2 - encode
    sts = m_pmfxENC->QueryIOSurf(&m_mfxEncParams, &EncRequest);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    
   
    // Rotation plugin requires 1 frame at input to produce 1 frame at output.
    mfxU16 nRotateReqIn, nRotateReqOut;    
    nRotateReqIn = nRotateReqOut = 1;   
        
    // If surfaces are shared by 2 components, c1 and c2. NumSurf = c2_in + (c1_out - 1) + extra    
    nEncSurfNum = EncRequest.NumFrameSuggested + (nRotateReqOut - 1) + (m_nAsyncDepth - 1);          
    nRotateSurfNum = nRotateReqIn + (nEncSurfNum - nRotateReqOut);    
            
    // prepare allocation requests
    EncRequest.NumFrameMin = EncRequest.NumFrameSuggested = nEncSurfNum; 
    RotateRequest.NumFrameMin = RotateRequest.NumFrameSuggested = nRotateSurfNum;
        
    EncRequest.Type = RotateRequest.Type = MFX_MEMTYPE_EXTERNAL_FRAME | MFX_MEMTYPE_SYSTEM_MEMORY;
    EncRequest.Type |= MFX_MEMTYPE_FROM_ENCODE;    
    RotateRequest.Type |= MFX_MEMTYPE_FROM_VPPOUT; // THIS IS A WORKAROUND, NEED TO ADJUST ALLOCATOR
        
    memcpy(&(EncRequest.Info), &(m_mfxEncParams.mfx.FrameInfo), sizeof(mfxFrameInfo));    
    memcpy(&(RotateRequest.Info), &(m_usrRotateParams.In), sizeof(mfxFrameInfo));
     
    // alloc frames for encoder input
    sts = m_pMFXAllocator->Alloc(m_pMFXAllocator->pthis, &EncRequest, &m_EncResponse);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
     
    // alloc frames for rotate input
    sts = m_pMFXAllocator->Alloc(m_pMFXAllocator->pthis, &(RotateRequest), &m_RotateResponse);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    // prepare mfxFrameSurface1 array for components    
    m_pEncSurfaces = new mfxFrameSurface1 [nEncSurfNum];
    CHECK_POINTER(m_pEncSurfaces, MFX_ERR_MEMORY_ALLOC);    
    m_pRotateSurfaces = new mfxFrameSurface1 [nRotateSurfNum];
    CHECK_POINTER(m_pRotateSurfaces, MFX_ERR_MEMORY_ALLOC);
    
    for (int i = 0; i < nEncSurfNum; i++)
    {       
        memset(&(m_pEncSurfaces[i]), 0, sizeof(mfxFrameSurface1));
        memcpy(&(m_pEncSurfaces[i].Info), &(m_mfxEncParams.mfx.FrameInfo), sizeof(mfxFrameInfo));
        // get YUV pointers
        sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, m_EncResponse.mids[i], &(m_pEncSurfaces[i].Data));
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);                  
    } 
    
    for (int i = 0; i < nRotateSurfNum; i++)
    {  
        memset(&(m_pRotateSurfaces[i]), 0, sizeof(mfxFrameSurface1));
        memcpy(&(m_pRotateSurfaces[i].Info), &(m_usrRotateParams.In), sizeof(mfxFrameInfo));
        sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, m_RotateResponse.mids[i], &(m_pRotateSurfaces[i].Data));
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);   
    }   
  
    return MFX_ERR_NONE;
}

void CUserPipeline::DeleteFrames()
{    
    SAFE_DELETE_ARRAY(m_pRotateSurfaces);     
    
    CEncodingPipeline::DeleteFrames();     
}

CUserPipeline::CUserPipeline() : CEncodingPipeline()
{     
    m_pRotateSurfaces = NULL; 
    ZERO_MEMORY(m_usrRotateParams);        
    ZERO_MEMORY(m_RotateResponse);
}

CUserPipeline::~CUserPipeline()
{
    Close();

	SAFE_DELETE(m_pFileWriter);
}

mfxStatus CUserPipeline::Init(sInputParams *pParams)
{   
    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);

    mfxStatus sts = MFX_ERR_NONE;

    // prepare input file reader
    sts = m_FileReader.Init(pParams->strSrcFile, pParams->ColorFormat);    
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    // prepare output file writer
	if(!pParams->bMux)
	{
		m_pFileWriter = new CSmplBitstreamWriter();
		sts = m_pFileWriter->Init(pParams->strDstFile);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}
	else
	{
		m_pFileWriter = new MuxWriter();
		sts = static_cast<MuxWriter*>(m_pFileWriter)->Init(
				pParams->strDstFile,
				pParams->nDstWidth,
				pParams->nDstHeight,
				pParams->dFrameRate,
				pParams->nBitRate,
				pParams->CodecId);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}
    
    mfxIMPL impl = pParams->bUseHWLib ? MFX_IMPL_HARDWARE : MFX_IMPL_SOFTWARE;
    mfxVersion version = {1, 1}; // pipeline with plugin requires media sdk API 1.1
    
    // create a session for the second vpp and encode
    sts = m_mfxSession.Init(impl, &version);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // create encoder
    m_pmfxENC = new MFXVideoENCODE(m_mfxSession);       
    CHECK_POINTER(m_pmfxENC, MFX_ERR_MEMORY_ALLOC);         
    
    sts = InitMfxEncParams(pParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);        

    sts = InitRotateParam(pParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // create and init frame allocator 
    sts = CreateAllocator();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);        

    m_nAsyncDepth = 4; // this number can be tuned for better performance

    sts = ResetMFXComponents(pParams); 
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);   
    
    sts = m_usrRotatePlugin.Init(&m_usrRotateParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);               

    sts = MFXVideoUSER_Register(m_mfxSession, 0, &m_usrRotatePlugin);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE;
}

void CUserPipeline::Close()
{      
    MFXVideoUSER_Unregister(m_mfxSession, 0);        

    CEncodingPipeline::Close();
}

mfxStatus CUserPipeline::ResetMFXComponents(sInputParams* pParams)
{
    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;    

    sts = m_pmfxENC->Close();
    IGNORE_MFX_STS(sts, MFX_ERR_NOT_INITIALIZED);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);         

    // free allocated frames
    DeleteFrames();

    m_TaskPool.Close();   
    
    sts = AllocFrames();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    sts = m_pmfxENC->Init(&m_mfxEncParams);    
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);             
    
    mfxU32 nEncodedDataBufferSize = m_mfxEncParams.mfx.FrameInfo.Width * m_mfxEncParams.mfx.FrameInfo.Height * 4;    
    sts = m_TaskPool.Init(&m_mfxSession, m_pFileWriter, m_nAsyncDepth, nEncodedDataBufferSize);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE;
}

mfxStatus CUserPipeline::Run()
{   
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;        

    sTask *pCurrentTask = NULL; // a pointer to the current task
    mfxU16 nEncSurfIdx = 0; // index of free surface for encoder input (vpp2 output)    
    mfxU16 nRotateSurfIdx = 0; // ~ for rotation plugin input     
    
    mfxSyncPoint RotateSyncPoint = NULL; // ~ with rotation plugin call

    PrintInfo();    

    sts = MFX_ERR_NONE;       

    // main loop, preprocessing and encoding
    while (MFX_ERR_NONE <= sts || MFX_ERR_MORE_DATA == sts)        
    {       
        // get a pointer to a free task (bit stream and sync point for encoder)
        sts = m_TaskPool.GetFreeTask(&pCurrentTask);
        BREAK_ON_ERROR(sts);        
         
        nRotateSurfIdx = GetFreeSurface(m_pRotateSurfaces, m_RotateResponse.NumFrameActual);
        CHECK_ERROR(nRotateSurfIdx, INVALID_SURF_IDX, MFX_ERR_MEMORY_ALLOC);

        sts = m_FileReader.LoadNextFrame(&m_pRotateSurfaces[nRotateSurfIdx]);
        BREAK_ON_ERROR(sts);        

        nEncSurfIdx = GetFreeSurface(m_pEncSurfaces, m_EncResponse.NumFrameActual);
        CHECK_ERROR(nEncSurfIdx, INVALID_SURF_IDX, MFX_ERR_MEMORY_ALLOC); 

        // rotation
        for(;;)
        {
            mfxHDL h1, h2;
            h1 = &m_pRotateSurfaces[nRotateSurfIdx];
            h2 = &m_pEncSurfaces[nEncSurfIdx];
            sts = MFXVideoUSER_ProcessFrameAsync(m_mfxSession, &h1, 1, &h2, 1, &RotateSyncPoint); 

            if (MFX_WRN_DEVICE_BUSY == sts)
            {
                Sleep(1); // just wait and then repeat the same call
            }
            else
            {
                break;
            }
        }                           
        
        BREAK_ON_ERROR(sts);                 
        
        // save the id of preceding rotate task which will produce input data for the encode task
        if (RotateSyncPoint)
        {
            pCurrentTask->DependentVppTasks.push_back(RotateSyncPoint);
            RotateSyncPoint = NULL;
        }

        for (;;)
        {            
            sts = m_pmfxENC->EncodeFrameAsync(NULL, &m_pEncSurfaces[nEncSurfIdx], &pCurrentTask->mfxBS, &pCurrentTask->EncSyncP);
            
            if (MFX_ERR_NONE < sts && !pCurrentTask->EncSyncP) // repeat the call if warning and no output
            {
                if (MFX_WRN_DEVICE_BUSY == sts)                
                    Sleep(1); // wait if device is busy                
            }
            else if (MFX_ERR_NONE < sts && pCurrentTask->EncSyncP)                 
            {
                sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                break;
            }
            else if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
            {
                sts = AllocateSufficientBuffer(&pCurrentTask->mfxBS);
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);                
            }
            else
            {
                break;
            }
        }            
    }

    // means that the input file has ended, need to go to buffering loops
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // exit in case of other errors
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    
    // rotate plugin doesn't buffer frames
    // loop to get buffered frames from encoder
    while (MFX_ERR_NONE <= sts)
    {       
        // get a free task (bit stream and sync point for encoder)
        sts = m_TaskPool.GetFreeTask(&pCurrentTask);
        BREAK_ON_ERROR(sts);

        for (;;)
        {                
            sts = m_pmfxENC->EncodeFrameAsync(NULL, NULL, &pCurrentTask->mfxBS, &pCurrentTask->EncSyncP);
            
            if (MFX_ERR_NONE < sts && !pCurrentTask->EncSyncP) // repeat the call if warning and no output
            {
                if (MFX_WRN_DEVICE_BUSY == sts)                
                    Sleep(1); // wait if device is busy                
            }
            else if (MFX_ERR_NONE < sts && pCurrentTask->EncSyncP)                 
            {
                sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                break;
            }
            else if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
            {
                sts = AllocateSufficientBuffer(&pCurrentTask->mfxBS);
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);
            }
            else
            {
                break;
            }
        }            
        BREAK_ON_ERROR(sts); 
    }    

    // MFX_ERR_MORE_DATA is the correct status to exit buffering loop with
    // indicates that there are no more buffered frames
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // exit in case of other errors
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // synchronize all tasks that are left in task pool
    while (MFX_ERR_NONE == sts)
    {
        sts = m_TaskPool.SynchronizeFirstTask();
    }  

    // MFX_ERR_NOT_FOUND is the correct status to exit the loop with,
    // EncodeFrameAsync and SyncOperation don't return this status
    IGNORE_MFX_STS(sts, MFX_ERR_NOT_FOUND); 
    // report any errors that occurred in asynchronous part
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);     

    return sts; 
}

void CUserPipeline::PrintInfo()
{       
    _tprintf(_T("\nPipeline with rotation plugin"));
    _tprintf(_T("\nNOTE: Some of command line options may have been ignored as non-supported for this pipeline. For details see readme-encode.rtf.\n\n"));

    CEncodingPipeline::PrintInfo();    
}