//
//               INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in accordance with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//

#include <windows.h>

#include "pipeline_encode.h"
#include "sysmem_allocator.h"

#ifdef D3D_SURFACES_SUPPORT
#include "d3d_allocator.h"
#endif

CEncTaskPool::CEncTaskPool()
{
    m_pTasks  = NULL;
    m_pmfxSession       = NULL;
    m_pWriter           = NULL;       
    m_nTaskBufferStart  = 0;
    m_nPoolSize         = 0;
}

CEncTaskPool::~CEncTaskPool()
{
    Close();
}

mfxStatus CEncTaskPool::Init(MFXVideoSession* pmfxSession, CSmplBitstreamWriter* pWriter, mfxU32 nPoolSize, mfxU32 nBufferSize)
{
    CHECK_POINTER(pmfxSession, MFX_ERR_NULL_PTR);
    CHECK_POINTER(pWriter, MFX_ERR_NULL_PTR);

    CHECK_ERROR(nPoolSize, 0, MFX_ERR_NOT_FOUND);
    CHECK_ERROR(nBufferSize, 0, MFX_ERR_NOT_FOUND);

    m_pmfxSession = pmfxSession;
    m_pWriter = pWriter;
    m_nPoolSize = nPoolSize;

    m_pTasks = new sTask [m_nPoolSize];  
    CHECK_POINTER(m_pTasks, MFX_ERR_MEMORY_ALLOC);

    mfxStatus sts = MFX_ERR_NONE;

    mfxU32 i = 0;
    for (i = 0; i < m_nPoolSize; i++)
    {       
        ZERO_MEMORY(m_pTasks[i].mfxBS);
        sts = InitMfxBitstream(&m_pTasks[i].mfxBS, nBufferSize);
        CHECK_RESULT_SAFE(sts, MFX_ERR_NONE, MFX_ERR_NOT_INITIALIZED, WipeMfxBitstream(&m_pTasks[i].mfxBS));
                
        ZERO_MEMORY(m_pTasks[i].EncSyncP);        
    }    

    return MFX_ERR_NONE;
}

mfxStatus CEncTaskPool::SynchronizeFirstTask()
{    
    CHECK_POINTER(m_pTasks, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(m_pmfxSession, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(m_pWriter, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts  = MFX_ERR_NONE;

    // non-null sync point indicates that task is in execution
    if (NULL != m_pTasks[m_nTaskBufferStart].EncSyncP)
    { 
        sts = m_pmfxSession->SyncOperation(m_pTasks[m_nTaskBufferStart].EncSyncP, WAIT_INTERVAL);        

        if (MFX_ERR_NONE == sts)
        {
            sts = m_pWriter->WriteNextFrame(&m_pTasks[m_nTaskBufferStart].mfxBS); 

            // mark sync point as free
            m_pTasks[m_nTaskBufferStart].EncSyncP = NULL;             

            // prepare bit stream
            m_pTasks[m_nTaskBufferStart].mfxBS.DataOffset = 0;
            m_pTasks[m_nTaskBufferStart].mfxBS.DataLength = 0;

            m_pTasks[m_nTaskBufferStart].DependentVppTasks.clear();

            // move task buffer start to the next executing task  
            // the first transform frame to the right with non zero sync point
            for (mfxU32 i = 0; i < m_nPoolSize; i++)
            {
                m_nTaskBufferStart = (m_nTaskBufferStart + 1) % m_nPoolSize;
                if (NULL != m_pTasks[m_nTaskBufferStart].EncSyncP)
                {
                    break;
                }
            }             
        } 
        else if (MFX_ERR_ABORTED == sts) 
        {
            while (!m_pTasks[m_nTaskBufferStart].DependentVppTasks.empty())
            {
                // find out if the error occurred in a VPP task to perform recovery procedure if applicable 
                sts = m_pmfxSession->SyncOperation(*m_pTasks[m_nTaskBufferStart].DependentVppTasks.begin(), 0);                

                if (MFX_ERR_NONE == sts)
                {
                    m_pTasks[m_nTaskBufferStart].DependentVppTasks.pop_front();
                    sts = MFX_ERR_ABORTED; // save the status of the encode task
                    continue; // go to next vpp task
                }
                else
                {
                    break;
                }
            }            
        }

        return sts;
    } 
    else
    {
        return MFX_ERR_NOT_FOUND; // no tasks left in task buffer
    }    
}

mfxU32 CEncTaskPool::GetFreeTaskIndex()
{    
    mfxU32 i = m_nPoolSize;

    if (m_pTasks)
    {
        for (i = 0; i < m_nPoolSize; i++)
        {            
            if (NULL == m_pTasks[i].EncSyncP)
            {                
                break;
            }
        }
    } 

    return i;
}

mfxStatus CEncTaskPool::GetFreeTask(sTask **ppTask)
{   
    CHECK_POINTER(ppTask, MFX_ERR_NULL_PTR);
    CHECK_POINTER(m_pTasks, MFX_ERR_NOT_INITIALIZED);

    mfxU32 index = m_nPoolSize; 
    mfxStatus sts;

    // if there is no free transform frame, wait for a task to complete
    if (GetFreeTaskIndex() >= m_nPoolSize)
    {
        sts = SynchronizeFirstTask();
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    }  

    index = GetFreeTaskIndex();

    if (index >= m_nPoolSize)
    {
        return MFX_ERR_NOT_ENOUGH_BUFFER;
    }

    // return the address of the task
    *ppTask = &m_pTasks[index];       

    return MFX_ERR_NONE; 
}

void CEncTaskPool::Close()
{  
    if (m_pTasks)
    {         
        for (mfxU32 i = 0; i < m_nPoolSize; i++)
        {    
            WipeMfxBitstream(&m_pTasks[i].mfxBS);                        
        }
    }

    SAFE_DELETE_ARRAY(m_pTasks);

    m_pmfxSession = NULL;
    m_pWriter = NULL;       
    m_nTaskBufferStart = 0;
    m_nPoolSize = 0;        
}

mfxStatus CEncodingPipeline::InitMfxEncParams(sInputParams *pInParams)
{
    m_mfxEncParams.mfx.CodecId                 = pInParams->CodecId;
    m_mfxEncParams.mfx.TargetUsage             = pInParams->nTargetUsage; // trade-off between quality and speed
    m_mfxEncParams.mfx.TargetKbps              = pInParams->nBitRate; // in Kbps
    m_mfxEncParams.mfx.RateControlMethod       = MFX_RATECONTROL_CBR; 
    ConvertFrameRate(pInParams->dFrameRate, &m_mfxEncParams.mfx.FrameInfo.FrameRateExtN, &m_mfxEncParams.mfx.FrameInfo.FrameRateExtD);
    m_mfxEncParams.mfx.NumThread               = pInParams->nThreads; // if 0 then encoder decides
    m_mfxEncParams.mfx.EncodedOrder            = 0; // binary flag, 0 signals encoder to take frames in display order

    // specify memory type
    if (pInParams->bd3dAlloc)
    {
        m_mfxEncParams.IOPattern = MFX_IOPATTERN_IN_VIDEO_MEMORY;
    }
    else
    {
        m_mfxEncParams.IOPattern = MFX_IOPATTERN_IN_SYSTEM_MEMORY;
    }    

    // frame info parameters
    m_mfxEncParams.mfx.FrameInfo.FourCC       = MFX_FOURCC_NV12;
    m_mfxEncParams.mfx.FrameInfo.ChromaFormat = MFX_CHROMAFORMAT_YUV420;
    m_mfxEncParams.mfx.FrameInfo.PicStruct    = pInParams->nPicStruct;

    // set frame size and crops
    // width must be a multiple of 16 
    // height must be a multiple of 16 in case of frame picture and a multiple of 32 in case of field picture
    m_mfxEncParams.mfx.FrameInfo.Width  = ALIGN16(pInParams->nDstWidth);
    m_mfxEncParams.mfx.FrameInfo.Height = (MFX_PICSTRUCT_PROGRESSIVE == m_mfxEncParams.mfx.FrameInfo.PicStruct)?
        ALIGN16(pInParams->nDstHeight) : ALIGN32(pInParams->nDstHeight);
    
    m_mfxEncParams.mfx.FrameInfo.CropX = 0; 
    m_mfxEncParams.mfx.FrameInfo.CropY = 0;
    m_mfxEncParams.mfx.FrameInfo.CropW = pInParams->nDstWidth;
    m_mfxEncParams.mfx.FrameInfo.CropH = pInParams->nDstHeight;
    
    // we don't specify profile and level and let the encoder choose those basing on parameters   


	if(pInParams->CodecId == MFX_CODEC_MPEG2)
	{
		m_mfxEncParams.mfx.IdrInterval = 1;	// Required for MPEG to insert sequence header before every I frame

		// GOP config required to ensure insertion of I-frames to be able to reposition efficientyl during decode.
		// At the moment an interval of 30 frames between each I frame selected.
		m_mfxEncParams.mfx.GopPicSize = 16;
		m_mfxEncParams.mfx.GopRefDist = 3;
	}
	else   // H.264
	{
		// GOP config required to ensure insertion of I-frames to be able to reposition efficientyl during decode.
		// At the moment an interval of 30 frames between each I frame selected.
		m_mfxEncParams.mfx.GopPicSize = 30;
		m_mfxEncParams.mfx.GopRefDist = 1;
	}

    return MFX_ERR_NONE;
}

mfxStatus CEncodingPipeline::CreateVppExtBuffers()
{
    // configure vpp DoNotUse hint 
    std::auto_ptr<mfxExtVPPDoNotUse> pExtDoNotUse(new mfxExtVPPDoNotUse); 
    CHECK_POINTER(pExtDoNotUse.get(), MFX_ERR_MEMORY_ALLOC);

    pExtDoNotUse->Header.BufferId = MFX_EXTBUFF_VPP_DONOTUSE;
    pExtDoNotUse->Header.BufferSz = sizeof(mfxExtVPPDoNotUse);
    pExtDoNotUse->NumAlg = 4;

    pExtDoNotUse->AlgList = new mfxU32 [pExtDoNotUse->NumAlg]; 
    CHECK_POINTER(pExtDoNotUse->AlgList, MFX_ERR_MEMORY_ALLOC);

    pExtDoNotUse->AlgList[0] = MFX_EXTBUFF_VPP_DENOISE; // turn off denoising (on by default)
    pExtDoNotUse->AlgList[1] = MFX_EXTBUFF_VPP_SCENE_ANALYSIS; // turn off scene analysis (on by default)
    pExtDoNotUse->AlgList[2] = MFX_EXTBUFF_VPP_DETAIL; // turn off detail enhancement (on by default)
    pExtDoNotUse->AlgList[3] = MFX_EXTBUFF_VPP_PROCAMP; // turn off processing amplified (on by default)

    // allocate external buffers array
    m_ppVppExtBuffers = new mfxExtBuffer* [1]; 
    CHECK_POINTER(m_ppVppExtBuffers, MFX_ERR_MEMORY_ALLOC);
    m_ppVppExtBuffers[0] = (mfxExtBuffer *)pExtDoNotUse.release();
    m_nNumVppExtBuffers = 1;

    return MFX_ERR_NONE;
}

void CEncodingPipeline::DeleteVppExtBuffers()
{
    // free external buffers
    if (m_ppVppExtBuffers)
    {
        for (mfxU8 i = 0; i < m_nNumVppExtBuffers; i++)
        {
            mfxExtVPPDoNotUse* pExtDoNotUse = (mfxExtVPPDoNotUse* )(m_ppVppExtBuffers[i]);
            SAFE_DELETE_ARRAY(pExtDoNotUse->AlgList);
            SAFE_DELETE(m_ppVppExtBuffers[i]);
        }        
    }

    SAFE_DELETE_ARRAY(m_ppVppExtBuffers);    
}

mfxStatus CEncodingPipeline::InitMfxVppParams(sInputParams *pInParams)
{
    CHECK_POINTER(pInParams,  MFX_ERR_NULL_PTR);   

    // specify memory type
    if (pInParams->bd3dAlloc)
    {
        m_mfxVppParams.IOPattern = MFX_IOPATTERN_IN_VIDEO_MEMORY | MFX_IOPATTERN_OUT_VIDEO_MEMORY;
    }
    else
    {
        m_mfxVppParams.IOPattern = MFX_IOPATTERN_IN_SYSTEM_MEMORY | MFX_IOPATTERN_OUT_SYSTEM_MEMORY;
    }    

    // input frame info  
    m_mfxVppParams.vpp.In.FourCC    = MFX_FOURCC_NV12;
    m_mfxVppParams.vpp.In.PicStruct = pInParams->nPicStruct;;
    ConvertFrameRate(pInParams->dFrameRate, &m_mfxVppParams.vpp.In.FrameRateExtN, &m_mfxVppParams.vpp.In.FrameRateExtD);

    // width must be a multiple of 16 
    // height must be a multiple of 16 in case of frame picture and a multiple of 32 in case of field picture
    m_mfxVppParams.vpp.In.Width     = ALIGN16(pInParams->nWidth); 
    m_mfxVppParams.vpp.In.Height    = (MFX_PICSTRUCT_PROGRESSIVE == m_mfxVppParams.vpp.In.PicStruct)?
        ALIGN16(pInParams->nHeight) : ALIGN32(pInParams->nHeight);

    // set crops in input mfxFrameInfo for correct work of file reader
    // VPP itself ignores crops at initialization
    m_mfxVppParams.vpp.In.CropW = pInParams->nWidth;
    m_mfxVppParams.vpp.In.CropH = pInParams->nHeight;

    // fill output frame info
    memcpy(&m_mfxVppParams.vpp.Out, &m_mfxVppParams.vpp.In, sizeof(mfxFrameInfo));

    // only resizing is supported
    m_mfxVppParams.vpp.Out.Width = ALIGN16(pInParams->nDstWidth);
    m_mfxVppParams.vpp.Out.Height = (MFX_PICSTRUCT_PROGRESSIVE == m_mfxVppParams.vpp.Out.PicStruct)?
        ALIGN16(pInParams->nDstHeight) : ALIGN32(pInParams->nDstHeight);    

    return MFX_ERR_NONE;
}

void CEncodingPipeline::InitVppExtParam()
{
    // attach external buffers array to mfxVideoParam
    m_mfxVppParams.ExtParam = m_ppVppExtBuffers;     
    m_mfxVppParams.NumExtParam = m_nNumVppExtBuffers;    
}

mfxStatus CEncodingPipeline::CreateDeviceManager()
{    
#ifdef D3D_SURFACES_SUPPORT
   m_pd3d = Direct3DCreate9(D3D_SDK_VERSION);
    if (!m_pd3d)
        return MFX_ERR_NULL_PTR;

    POINT point = {0, 0};
    HWND window = WindowFromPoint(point);

    D3DPRESENT_PARAMETERS d3dParams;
    memset(&d3dParams, 0, sizeof(d3dParams));
    d3dParams.Windowed = TRUE;
    d3dParams.hDeviceWindow = window;
    d3dParams.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dParams.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
    d3dParams.Flags = D3DPRESENTFLAG_VIDEO;
    d3dParams.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
    d3dParams.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    d3dParams.BackBufferCount = 1;
    d3dParams.BackBufferFormat = D3DFMT_X8R8G8B8;
    d3dParams.BackBufferWidth = 0;
    d3dParams.BackBufferHeight = 0;
    
    HRESULT hr = m_pd3d->CreateDevice(
        D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        window,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING | D3DCREATE_MULTITHREADED | D3DCREATE_FPU_PRESERVE,
        &d3dParams,
        &m_pd3dDevice);
    if (FAILED(hr))
        return MFX_ERR_NULL_PTR;

    UINT resetToken = 0;    
    hr = DXVA2CreateDirect3DDeviceManager9(&resetToken, &m_pd3dDeviceManager);
    if (FAILED(hr))
        return MFX_ERR_NULL_PTR;

    hr = m_pd3dDeviceManager->ResetDevice(m_pd3dDevice, resetToken);
    if (FAILED(hr))
        return MFX_ERR_UNDEFINED_BEHAVIOR;
    
    m_resetToken = resetToken;   
#endif
    return MFX_ERR_NONE;
}

mfxStatus CEncodingPipeline::ResetDevice()
{
    if (m_bd3dAlloc)
    {
#ifdef D3D_SURFACES_SUPPORT
    HRESULT hr = m_pd3dDeviceManager->ResetDevice(m_pd3dDevice, m_resetToken);
    if (FAILED(hr))
        return MFX_ERR_UNDEFINED_BEHAVIOR;
    else
        return MFX_ERR_NONE;
#endif
    }
    else
    {
        return MFX_ERR_NONE;
    }
}

mfxStatus CEncodingPipeline::AllocFrames()
{    
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;
    mfxFrameAllocRequest EncRequest;
    mfxFrameAllocRequest VppRequest[2];

    mfxU16 nEncSurfNum = 0; // number of surfaces for encoder
    mfxU16 nVppSurfNum = 0; // number of surfaces for vpp

    ZERO_MEMORY(EncRequest);
    ZERO_MEMORY(VppRequest[0]);
    ZERO_MEMORY(VppRequest[1]);

    // Calculate the number of surfaces for components.
    // QueryIOSurf functions tell how many surfaces are required to produce at least 1 output. 
    // To achieve better performance we provide extra surfaces. 
    // 1 extra surface at input allows to get 1 extra output.   
    sts = m_pmfxENC->QueryIOSurf(&m_mfxEncParams, &EncRequest);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);             

    if (m_pmfxVPP)
    {
        // VppRequest[0] for input frames request, VppRequest[1] for output frames request
        sts = m_pmfxVPP->QueryIOSurf(&m_mfxVppParams, VppRequest);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);               
    }

    // The number of surfaces shared by vpp output and encode input.
    // When surfaces are shared 1 surface at first component output contains output frame that goes to next component input
    nEncSurfNum = EncRequest.NumFrameSuggested + MAX(VppRequest[1].NumFrameSuggested, 1) - 1 + (m_nAsyncDepth - 1); 

    // The number of surfaces for vpp input 
    nVppSurfNum = VppRequest[0].NumFrameSuggested + nEncSurfNum - VppRequest[1].NumFrameSuggested; 

    // prepare allocation requests
    EncRequest.NumFrameMin = nEncSurfNum;
    EncRequest.NumFrameSuggested = nEncSurfNum;
    memcpy(&(EncRequest.Info), &(m_mfxEncParams.mfx.FrameInfo), sizeof(mfxFrameInfo));
    EncRequest.Type = MFX_MEMTYPE_EXTERNAL_FRAME | MFX_MEMTYPE_FROM_ENCODE;
    if (m_pmfxVPP)
    {
        EncRequest.Type |= MFX_MEMTYPE_FROM_VPPOUT; // surfaces are shared between vpp output and encode input 
    }
    // add info about memory type to request 
    EncRequest.Type |= m_bd3dAlloc ? MFX_MEMTYPE_DXVA2_DECODER_TARGET : MFX_MEMTYPE_SYSTEM_MEMORY; 

    // alloc frames for encoder
    sts = m_pMFXAllocator->Alloc(m_pMFXAllocator->pthis, &EncRequest, &m_EncResponse);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // alloc frames for vpp if vpp is enabled
    if (m_pmfxVPP)
    {
        VppRequest[0].NumFrameMin = nVppSurfNum;
        VppRequest[0].NumFrameSuggested = nVppSurfNum;
        memcpy(&(VppRequest[0].Info), &(m_mfxVppParams.mfx.FrameInfo), sizeof(mfxFrameInfo));
        VppRequest[0].Type = MFX_MEMTYPE_EXTERNAL_FRAME | MFX_MEMTYPE_FROM_VPPIN;  
        // add info about memory type to request 
        VppRequest[0].Type |= m_bd3dAlloc ? MFX_MEMTYPE_DXVA2_DECODER_TARGET : MFX_MEMTYPE_SYSTEM_MEMORY; 
        VppRequest[1].Type |= m_bd3dAlloc ? MFX_MEMTYPE_DXVA2_DECODER_TARGET : MFX_MEMTYPE_SYSTEM_MEMORY;

        sts = m_pMFXAllocator->Alloc(m_pMFXAllocator->pthis, &(VppRequest[0]), &m_VppResponse);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    }

    // prepare mfxFrameSurface1 array for encoder    
    m_pEncSurfaces = new mfxFrameSurface1 [m_EncResponse.NumFrameActual];
    CHECK_POINTER(m_pEncSurfaces, MFX_ERR_MEMORY_ALLOC);

    for (int i = 0; i < m_EncResponse.NumFrameActual; i++)
    {       
        memset(&(m_pEncSurfaces[i]), 0, sizeof(mfxFrameSurface1));
        memcpy(&(m_pEncSurfaces[i].Info), &(m_mfxEncParams.mfx.FrameInfo), sizeof(mfxFrameInfo));

        if (m_bExternalAlloc)
        {            
            m_pEncSurfaces[i].Data.MemId = m_EncResponse.mids[i];    
        }
        else
        {
            // get YUV pointers
            sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, m_EncResponse.mids[i], &(m_pEncSurfaces[i].Data));
            CHECK_RESULT(sts, MFX_ERR_NONE, sts);
        }
    }

    // prepare mfxFrameSurface1 array for vpp if vpp is enabled
    if (m_pmfxVPP)
    {        
        m_pVppSurfaces = new mfxFrameSurface1 [m_VppResponse.NumFrameActual]; 
        CHECK_POINTER(m_pVppSurfaces, MFX_ERR_MEMORY_ALLOC);

        for (int i = 0; i < m_VppResponse.NumFrameActual; i++)
        {       
            memset(&(m_pVppSurfaces[i]), 0, sizeof(mfxFrameSurface1));
            memcpy(&(m_pVppSurfaces[i].Info), &(m_mfxVppParams.mfx.FrameInfo), sizeof(mfxFrameInfo));

            if (m_bExternalAlloc)
            {
                m_pVppSurfaces[i].Data.MemId = m_VppResponse.mids[i];    
            }
            else
            {
                sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, m_VppResponse.mids[i], &(m_pVppSurfaces[i].Data));
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);
            }
        }        
    }

    return MFX_ERR_NONE;
}

mfxStatus CEncodingPipeline::CreateAllocator()
{   
    mfxStatus sts = MFX_ERR_NONE;

    if (m_bd3dAlloc)
    {
#ifdef D3D_SURFACES_SUPPORT       
        sts = CreateDeviceManager();
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        // provide device manager to MediaSDK
        sts = m_mfxSession.SetHandle(MFX_HANDLE_DIRECT3D_DEVICE_MANAGER9, m_pd3dDeviceManager);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        // crate D3D allocator
        m_pMFXAllocator = new D3DFrameAllocator; 
        CHECK_POINTER(m_pMFXAllocator, MFX_ERR_MEMORY_ALLOC);

        D3DAllocatorParams *pd3dAllocParams = new D3DAllocatorParams; 
        CHECK_POINTER(pd3dAllocParams, MFX_ERR_MEMORY_ALLOC);

        pd3dAllocParams->pManager = m_pd3dDeviceManager;
        m_pmfxAllocatorParams = pd3dAllocParams;

        /* In case of video memory we must provide Media SDK with external allocator 
        thus we demonstrate "external allocator" usage model.
        Call SetAllocator to pass allocator to Media SDK */
        sts = m_mfxSession.SetFrameAllocator(m_pMFXAllocator);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        m_bExternalAlloc = true;  
#endif
    } 
    else
    {        
        // create system memory allocator       
        m_pMFXAllocator = new SysMemFrameAllocator; 
        CHECK_POINTER(m_pMFXAllocator, MFX_ERR_MEMORY_ALLOC);

        /* In case of system memory we demonstrate "no external allocator" usage model.  
        We don't call SetAllocator, Media SDK uses internal allocator. 
        We use system memory allocator simply as a memory manager for application*/           
    }   

    // initialize memory allocator
    sts = m_pMFXAllocator->Init(m_pmfxAllocatorParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE; 
}

void CEncodingPipeline::DeleteFrames()
{
    // delete surfaces array
    SAFE_DELETE_ARRAY(m_pEncSurfaces);    
    SAFE_DELETE_ARRAY(m_pVppSurfaces);    

    // delete frames
    if (m_pMFXAllocator)
    {        
        m_pMFXAllocator->Free(m_pMFXAllocator->pthis, &m_EncResponse);
        m_pMFXAllocator->Free(m_pMFXAllocator->pthis, &m_VppResponse);
    }    
}

void CEncodingPipeline::DeleteDeviceManager()
{
#ifdef D3D_SURFACES_SUPPORT 
    SAFE_RELEASE(m_pd3dDevice);
    SAFE_RELEASE(m_pd3dDeviceManager);
    SAFE_RELEASE(m_pd3d);  
#endif      
}

void CEncodingPipeline::DeleteAllocator()
{    
    // delete allocator
    SAFE_DELETE(m_pMFXAllocator);   
    SAFE_DELETE(m_pmfxAllocatorParams);

    DeleteDeviceManager();
}

CEncodingPipeline::CEncodingPipeline()
{    
    m_pmfxENC = NULL;
    m_pmfxVPP = NULL;
    m_pMFXAllocator = NULL;
    m_pmfxAllocatorParams = NULL;
    m_bd3dAlloc = false;
    m_bExternalAlloc = false;
    m_pEncSurfaces = NULL;   
    m_pVppSurfaces = NULL;
    m_nAsyncDepth = 0;

#ifdef D3D_SURFACES_SUPPORT
    m_pd3d = NULL;
    m_pd3dDeviceManager = NULL;  
    m_pd3dDevice        = NULL;
    m_resetToken        = 0;
#endif 

	m_pFileWriter = NULL;

    ZERO_MEMORY(m_mfxEncParams);
    ZERO_MEMORY(m_mfxVppParams);
    m_ppVppExtBuffers = NULL;
    m_nNumVppExtBuffers = 0;

    ZERO_MEMORY(m_EncResponse); 
    ZERO_MEMORY(m_VppResponse);
}

CEncodingPipeline::~CEncodingPipeline()
{
    Close();

	SAFE_DELETE(m_pFileWriter);
}

mfxStatus CEncodingPipeline::Init(sInputParams *pParams)
{
    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);

    mfxStatus sts = MFX_ERR_NONE;

    // prepare input file reader
    sts = m_FileReader.Init(pParams->strSrcFile, pParams->ColorFormat);    
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    // prepare output file writer
	if(!pParams->bMux)
	{
		m_pFileWriter = new CSmplBitstreamWriter();
		sts = m_pFileWriter->Init(pParams->strDstFile);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}
	else
	{
		m_pFileWriter = new MuxWriter();
		sts = static_cast<MuxWriter*>(m_pFileWriter)->Init(
				pParams->strDstFile,
				pParams->nDstWidth,
				pParams->nDstHeight,
				pParams->dFrameRate,
				pParams->nBitRate,
				pParams->CodecId);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}

    // init session
    mfxIMPL impl = pParams->bUseHWLib ? MFX_IMPL_HARDWARE : MFX_IMPL_SOFTWARE;
    mfxVersion version = {0, 1}; // API 1.0 is enough for this pipeline   
    sts = m_mfxSession.Init(impl, &version);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // set memory type
    m_bd3dAlloc = pParams->bd3dAlloc;     
    
    // create and init frame allocator 
    sts = CreateAllocator();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    sts = InitMfxEncParams(pParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    sts = InitMfxVppParams(pParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    sts = CreateVppExtBuffers();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    InitVppExtParam();

    // create encoder
    m_pmfxENC = new MFXVideoENCODE(m_mfxSession); 
    CHECK_POINTER(m_pmfxENC, MFX_ERR_MEMORY_ALLOC);

    // create preprocessor if resizing was requested from command line 
    // or if different FourCC is set in InitMfxVppParams
    if (pParams->nWidth  != pParams->nDstWidth ||
        pParams->nHeight != pParams->nDstHeight ||
        m_mfxVppParams.vpp.In.FourCC != m_mfxVppParams.vpp.Out.FourCC)
    {
        m_pmfxVPP = new MFXVideoVPP(m_mfxSession);
        CHECK_POINTER(m_pmfxVPP, MFX_ERR_MEMORY_ALLOC);
    }  

    m_nAsyncDepth = 4; // this number can be tuned for better performance

    sts = ResetMFXComponents(pParams); 
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);      
    

    return MFX_ERR_NONE;
}

void CEncodingPipeline::Close()
{    
    _tprintf(_T("Frame number: %hd\r"), m_pFileWriter->m_nProcessedFramesNum); 
    
    SAFE_DELETE(m_pmfxENC);
    SAFE_DELETE(m_pmfxVPP);

    DeleteVppExtBuffers();
    DeleteFrames();    
    // allocator if used as external for MediaSDK must be deleted after SDK components
    DeleteAllocator();

    m_TaskPool.Close();
    m_mfxSession.Close();

    m_pFileWriter->Close();
    m_FileReader.Close();    
}

mfxStatus CEncodingPipeline::ResetMFXComponents(sInputParams* pParams)
{
    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;    

    sts = m_pmfxENC->Close();
    IGNORE_MFX_STS(sts, MFX_ERR_NOT_INITIALIZED);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    if (m_pmfxVPP)
    {
        sts = m_pmfxVPP->Close();
        IGNORE_MFX_STS(sts, MFX_ERR_NOT_INITIALIZED);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    }    

    // free allocated frames
    DeleteFrames();

    m_TaskPool.Close();   
    
    sts = AllocFrames();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    sts = m_pmfxENC->Init(&m_mfxEncParams);
    IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    if (m_pmfxVPP)
    {
        sts = m_pmfxVPP->Init(&m_mfxVppParams);
        IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    }

    mfxU32 nEncodedDataBufferSize = m_mfxEncParams.mfx.FrameInfo.Width * m_mfxEncParams.mfx.FrameInfo.Height * 4;    
    sts = m_TaskPool.Init(&m_mfxSession, m_pFileWriter, m_nAsyncDepth, nEncodedDataBufferSize);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE;
}

mfxStatus CEncodingPipeline::AllocateSufficientBuffer(mfxBitstream* pBS)
{    
    CHECK_POINTER(pBS, MFX_ERR_NULL_PTR);
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxVideoParam par;
    ZERO_MEMORY(par);

    // find out the required buffer size
    mfxStatus sts = m_pmfxENC->GetVideoParam(&par);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts); 

    // reallocate bigger buffer for output
    sts = ExtendMfxBitstream(pBS, par.mfx.BufferSizeInKB * 1000); 
    CHECK_RESULT_SAFE(sts, MFX_ERR_NONE, sts, WipeMfxBitstream(pBS));

    return MFX_ERR_NONE;
}

mfxStatus CEncodingPipeline::Run()
{   
    CHECK_POINTER(m_pmfxENC, MFX_ERR_NOT_INITIALIZED);

    mfxStatus sts = MFX_ERR_NONE;    
    
    mfxFrameSurface1* pSurf = NULL; // dispatching pointer    

    sTask *pCurrentTask = NULL; // a pointer to the current task
    mfxU16 nEncSurfIdx = 0; // index of free surface for encoder input (vpp output)
    mfxU16 nVppSurfIdx = 0; // index of free surface for vpp input
    
    mfxSyncPoint VppSyncPoint = NULL; // a sync point associated with an asynchronous vpp call
    bool bVppMultipleOutput = false; // this flag is true if VPP produces more frames at output 
                                     // than consumes at input. E.g. framerate conversion 30 fps -> 60 fps
    PrintInfo();    
    
    sts = MFX_ERR_NONE;       

    // main loop, preprocessing and encoding
    while (MFX_ERR_NONE <= sts || MFX_ERR_MORE_DATA == sts)        
    {        
        // get a pointer to a free task (bit stream and sync point for encoder)
        sts = m_TaskPool.GetFreeTask(&pCurrentTask);
        BREAK_ON_ERROR(sts);

        // find free surface for encoder input
        nEncSurfIdx = GetFreeSurface(m_pEncSurfaces, m_EncResponse.NumFrameActual);
        CHECK_ERROR(nEncSurfIdx, INVALID_SURF_IDX, MFX_ERR_MEMORY_ALLOC);

        // point pSurf to encoder surface
        pSurf = &m_pEncSurfaces[nEncSurfIdx];

        if (!bVppMultipleOutput)
        {
            // if vpp is enabled find free surface for vpp input and point pSurf to vpp surface
            if (m_pmfxVPP)
            {          
                nVppSurfIdx = GetFreeSurface(m_pVppSurfaces, m_VppResponse.NumFrameActual);
                CHECK_ERROR(nVppSurfIdx, INVALID_SURF_IDX, MFX_ERR_MEMORY_ALLOC);

                pSurf = &m_pVppSurfaces[nVppSurfIdx];
            }        

            // load frame from file to surface data
            // if we share allocator with Media SDK we need to call Lock to access surface data and after we're done call Unlock
            if (m_bExternalAlloc) 
            {
                // get YUV pointers
                sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, pSurf->Data.MemId, &(pSurf->Data));
                BREAK_ON_ERROR(sts);

                sts = m_FileReader.LoadNextFrame(pSurf);
                BREAK_ON_ERROR(sts);

                sts = m_pMFXAllocator->Unlock(m_pMFXAllocator->pthis, pSurf->Data.MemId, &(pSurf->Data));
                BREAK_ON_ERROR(sts);
            }
            else 
            {
                sts = m_FileReader.LoadNextFrame(pSurf);
                BREAK_ON_ERROR(sts);
            }
        }        

        // perform preprocessing if required
        if (m_pmfxVPP)
        {            
            bVppMultipleOutput = false; // reset the flag before a call to VPP
            for (;;)
            {
                sts = m_pmfxVPP->RunFrameVPPAsync(&m_pVppSurfaces[nVppSurfIdx], &m_pEncSurfaces[nEncSurfIdx], 
                    NULL, &VppSyncPoint); 

                if (MFX_ERR_NONE < sts && !VppSyncPoint) // repeat the call if warning and no output
                {
                    if (MFX_WRN_DEVICE_BUSY == sts)                
                        Sleep(1); // wait if device is busy                    
                }
                else if (MFX_ERR_NONE < sts && VppSyncPoint)                 
                {
                    sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                    break;
                }
                else 
                    break; // not a warning               
            } 
            
            // process errors            
            if (MFX_ERR_MORE_DATA == sts)
            {
                continue;
            }
            else if (MFX_ERR_MORE_SURFACE == sts)
            {
                bVppMultipleOutput = true;
            }
            else
            {
                BREAK_ON_ERROR(sts); 
            }
        }                       
        
        // save the id of preceding vpp task which will produce input data for the encode task
        if (VppSyncPoint)
        {
            pCurrentTask->DependentVppTasks.push_back(VppSyncPoint);
            VppSyncPoint = NULL;
        }

        for (;;)
        {
            // at this point surface for encoder contains either a frame from file or a frame processed by vpp        
            sts = m_pmfxENC->EncodeFrameAsync(NULL, &m_pEncSurfaces[nEncSurfIdx], &pCurrentTask->mfxBS, &pCurrentTask->EncSyncP);
            
            if (MFX_ERR_NONE < sts && !pCurrentTask->EncSyncP) // repeat the call if warning and no output
            {
                if (MFX_WRN_DEVICE_BUSY == sts)                
                    Sleep(1); // wait if device is busy                
            }
            else if (MFX_ERR_NONE < sts && pCurrentTask->EncSyncP)                 
            {
                sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                break;
            }
            else if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
            {
                sts = AllocateSufficientBuffer(&pCurrentTask->mfxBS);
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);                
            }
            else
            {
                break;
            }
        }            
    }

    // means that the input file has ended, need to go to buffering loops
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // exit in case of other errors
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    if (m_pmfxVPP)
    {
        // loop to get buffered frames from vpp
        while (MFX_ERR_NONE <= sts || MFX_ERR_MORE_DATA == sts || MFX_ERR_MORE_SURFACE == sts)
            // MFX_ERR_MORE_SURFACE can be returned only by RunFrameVPPAsync
            // MFX_ERR_MORE_DATA is accepted only from EncodeFrameAsync
        {      
            // find free surface for encoder input (vpp output)
            nEncSurfIdx = GetFreeSurface(m_pEncSurfaces, m_EncResponse.NumFrameActual);
            CHECK_ERROR(nEncSurfIdx, INVALID_SURF_IDX, MFX_ERR_MEMORY_ALLOC);
                      
            for (;;)
            {
                sts = m_pmfxVPP->RunFrameVPPAsync(NULL, &m_pEncSurfaces[nEncSurfIdx], NULL, &VppSyncPoint); 

                if (MFX_ERR_NONE < sts && !VppSyncPoint) // repeat the call if warning and no output
                {
                    if (MFX_WRN_DEVICE_BUSY == sts)                
                        Sleep(1); // wait if device is busy                    
                }
                else if (MFX_ERR_NONE < sts && VppSyncPoint)                 
                {
                    sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                    break;
                }
                else 
                    break; // not a warning               
            }    

            if (MFX_ERR_MORE_SURFACE == sts)
            {
                continue;
            }
            else
            {
                BREAK_ON_ERROR(sts); 
            }                        

            // get a free task (bit stream and sync point for encoder)
            sts = m_TaskPool.GetFreeTask(&pCurrentTask);
            BREAK_ON_ERROR(sts);

            // save the id of preceding vpp task which will produce input data for the encode task
            if (VppSyncPoint)
            {
                pCurrentTask->DependentVppTasks.push_back(VppSyncPoint);
                VppSyncPoint = NULL;
            }

            for (;;)
            {                
                sts = m_pmfxENC->EncodeFrameAsync(NULL, &m_pEncSurfaces[nEncSurfIdx], &pCurrentTask->mfxBS, &pCurrentTask->EncSyncP);                

                if (MFX_ERR_NONE < sts && !pCurrentTask->EncSyncP) // repeat the call if warning and no output
                {
                    if (MFX_WRN_DEVICE_BUSY == sts)                
                        Sleep(1); // wait if device is busy                
                }
                else if (MFX_ERR_NONE < sts && pCurrentTask->EncSyncP)                 
                {
                    sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                    break;
                }
                else if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
                {
                    sts = AllocateSufficientBuffer(&pCurrentTask->mfxBS);
                    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
                }
                else
                {
                    break;
                }
            }            
        }

        // MFX_ERR_MORE_DATA is the correct status to exit buffering loop with
        // indicates that there are no more buffered frames
        IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
        // exit in case of other errors
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);  
    }    

    // loop to get buffered frames from encoder
    while (MFX_ERR_NONE <= sts)
    {       
        // get a free task (bit stream and sync point for encoder)
        sts = m_TaskPool.GetFreeTask(&pCurrentTask);
        BREAK_ON_ERROR(sts);
        
        for (;;)
        {                
            sts = m_pmfxENC->EncodeFrameAsync(NULL, NULL, &pCurrentTask->mfxBS, &pCurrentTask->EncSyncP);            

            if (MFX_ERR_NONE < sts && !pCurrentTask->EncSyncP) // repeat the call if warning and no output
            {
                if (MFX_WRN_DEVICE_BUSY == sts)                
                    Sleep(1); // wait if device is busy                
            }
            else if (MFX_ERR_NONE < sts && pCurrentTask->EncSyncP)                 
            {
                sts = MFX_ERR_NONE; // ignore warnings if output is available                                    
                break;
            }
            else if (MFX_ERR_NOT_ENOUGH_BUFFER == sts)
            {
                sts = AllocateSufficientBuffer(&pCurrentTask->mfxBS);
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);
            }
            else
            {
                break;
            }
        }            
        BREAK_ON_ERROR(sts); 
    }    

    // MFX_ERR_MORE_DATA is the correct status to exit buffering loop with
    // indicates that there are no more buffered frames
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // exit in case of other errors
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // synchronize all tasks that are left in task pool
    while (MFX_ERR_NONE == sts)
    {
        sts = m_TaskPool.SynchronizeFirstTask();
    }  

    // MFX_ERR_NOT_FOUND is the correct status to exit the loop with
    // EncodeFrameAsync and SyncOperation don't return this status
    IGNORE_MFX_STS(sts, MFX_ERR_NOT_FOUND); 
    // report any errors that occurred in asynchronous part
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);     

    return sts; 
}

void CEncodingPipeline::PrintInfo()
{       
    _tprintf(_T("\nInput file format\t%s\n"), ColorFormatToStr(m_FileReader.m_ColorFormat));
    _tprintf(_T("Output video\t\t%s\n"), CodecIdToStr(m_mfxEncParams.mfx.CodecId));

    mfxFrameInfo SrcPicInfo = m_mfxVppParams.vpp.In;
    mfxFrameInfo DstPicInfo = m_mfxEncParams.mfx.FrameInfo;    

    _tprintf(_T("Source picture:\n"));
    _tprintf(_T("\tResolution\t%dx%d\n"), SrcPicInfo.Width, SrcPicInfo.Height);
    _tprintf(_T("\tCrop X,Y,W,H\t%d,%d,%d,%d\n"), SrcPicInfo.CropX, SrcPicInfo.CropY, SrcPicInfo.CropW, SrcPicInfo.CropH);

    _tprintf(_T("Destination picture:\n"));
    _tprintf(_T("\tResolution\t%dx%d\n"), DstPicInfo.Width, DstPicInfo.Height);
    _tprintf(_T("\tCrop X,Y,W,H\t%d,%d,%d,%d\n"), DstPicInfo.CropX, DstPicInfo.CropY, DstPicInfo.CropW, DstPicInfo.CropH);
     
    _tprintf(_T("Frame rate\t%.2f\n"), DstPicInfo.FrameRateExtN * 1.0 / DstPicInfo.FrameRateExtD);
    _tprintf(_T("Bit rate(Kbps)\t%d\n"), m_mfxEncParams.mfx.TargetKbps);
    _tprintf(_T("Target usage\t%s\n"), TargetUsageToStr(m_mfxEncParams.mfx.TargetUsage));

    TCHAR* sMemType = m_bd3dAlloc ? _T("d3d") : _T("system");
    _tprintf(_T("Memory type\t%s\n"), sMemType);

    mfxIMPL impl;
    m_mfxSession.QueryIMPL(&impl);

    TCHAR* sImpl = (MFX_IMPL_HARDWARE == impl) ? _T("hw") : _T("sw");
    _tprintf(_T("Media SDK impl\t\t%s\n"), sImpl);

    mfxVersion ver;
    m_mfxSession.QueryVersion(&ver);
    _tprintf(_T("Media SDK version\t%d.%d\n"), ver.Major, ver.Minor);   

    _tprintf(_T("\n"));    
}