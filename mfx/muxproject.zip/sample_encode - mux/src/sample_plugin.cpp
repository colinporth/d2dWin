//* ////////////////////////////////////////////////////////////////////////////// */
//*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2010 Intel Corporation. All Rights Reserved.
//
//
//*/

#include "sample_plugin.h"

// disable "unreferenced formal parameter" warning - 
// not all formal parameters of interface functions will be used by sample plugin
#pragma warning(disable : 4100) 

#define SWAP_BYTES(a, b) {mfxU8 tmp; tmp = a; a = b; b = tmp;}

/* MFXPlugin class implementation */
MFXPlugin::MFXPlugin()
{
    pthis = this;
    // initialize callbacks
    PluginInit = MFXPlugin::PluginInit_;
    PluginClose = MFXPlugin::PluginClose_;
    GetPluginParam = MFXPlugin::GetPluginParam_;
    Submit = MFXPlugin::Submit_;
    Execute = MFXPlugin::Execute_;
    FreeResources = MFXPlugin::FreeResources_;
}

MFXPlugin::~MFXPlugin()
{
}

mfxStatus MFXPlugin::PluginInit_(mfxHDL pthis, mfxCoreInterface *core)
{   
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxPluginInit(core);
}

mfxStatus MFXPlugin::PluginClose_(mfxHDL pthis)
{
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxPluginClose();
}

mfxStatus MFXPlugin::GetPluginParam_(mfxHDL pthis, mfxPluginParam *par)
{
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxGetPluginParam(par);
}

mfxStatus MFXPlugin::Submit_(mfxHDL pthis, const mfxHDL *in, mfxU32 in_num, const mfxHDL *out, mfxU32 out_num, mfxThreadTask *task)
{
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxSubmit(in, in_num, out, out_num, task);
}

mfxStatus MFXPlugin::Execute_(mfxHDL pthis, mfxThreadTask task, mfxU32 thread_id, mfxU32 call_count)
{
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxExecute(task, thread_id, call_count);
}

mfxStatus MFXPlugin::FreeResources_(mfxHDL pthis, mfxThreadTask task, mfxStatus sts)
{
    CHECK_POINTER(pthis, MFX_ERR_NULL_PTR);    

    MFXPlugin *pSelf = (MFXPlugin *)pthis;
    return pSelf->mfxFreeResources(task, sts);
}

/* Rotate class implementation */
Rotate::Rotate() : 
m_pTasks(NULL),
m_bInited(false)
{
    memset(&m_pmfxCore, 0, sizeof(mfxCoreInterface));
    memset(&m_Param, 0, sizeof(RotateParam));
}

Rotate::~Rotate()
{
    mfxPluginClose();
}

/* Methods required for integration with Media SDK */
mfxStatus Rotate::mfxPluginInit(mfxCoreInterface *core)
{
    CHECK_POINTER(core, MFX_ERR_NULL_PTR);       
        
    SAFE_DELETE(m_pmfxCore);

    m_pmfxCore = new mfxCoreInterface; 
    CHECK_POINTER(m_pmfxCore, MFX_ERR_MEMORY_ALLOC);
    *m_pmfxCore = *core;    

    return MFX_ERR_NONE;
}

mfxStatus Rotate::mfxPluginClose()
{
    SAFE_DELETE(m_pmfxCore);
 
    return MFX_ERR_NONE;
}

mfxStatus Rotate::mfxGetPluginParam(mfxPluginParam *par)
{
    CHECK_POINTER(par, MFX_ERR_NULL_PTR);    

    *par = *(mfxPluginParam *)&m_Param;

    return MFX_ERR_NONE;
}

mfxStatus Rotate::mfxSubmit(const mfxHDL *in, mfxU32 in_num, const mfxHDL *out, mfxU32 out_num, mfxThreadTask *task)
{
    CHECK_POINTER(in, MFX_ERR_NULL_PTR);
    CHECK_POINTER(out, MFX_ERR_NULL_PTR);
    CHECK_POINTER(*in, MFX_ERR_NULL_PTR);
    CHECK_POINTER(*out, MFX_ERR_NULL_PTR);
    CHECK_POINTER(task, MFX_ERR_NULL_PTR);    
    CHECK_NOT_EQUAL(in_num, 1, MFX_ERR_UNSUPPORTED);
    CHECK_NOT_EQUAL(out_num, 1, MFX_ERR_UNSUPPORTED);
    CHECK_POINTER(m_pmfxCore, MFX_ERR_NOT_INITIALIZED);  
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);  

    mfxFrameSurface1 *surface_in = (mfxFrameSurface1 *)in[0];
    mfxFrameSurface1 *surface_out = (mfxFrameSurface1 *)out[0];          
    
    mfxStatus sts = MFX_ERR_NONE;

    // check validity of parameters
    sts = CheckInOutFrameInfo(&surface_in->Info, &surface_out->Info);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    sts = CheckFrameData(surface_in);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    sts = CheckFrameData(surface_out);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
        
    mfxU32 ind = FindFreeTaskIdx();

    if (ind >= m_Param.MaxNumTasks)
    {
        return MFX_WRN_DEVICE_BUSY; // currently there are no free tasks available
    }
    
    m_pmfxCore->IncreaseReference(m_pmfxCore->pthis, &(surface_in->Data));
    m_pmfxCore->IncreaseReference(m_pmfxCore->pthis, &(surface_out->Data));

    m_pTasks[ind].In = surface_in;
    m_pTasks[ind].Out = surface_out;
    m_pTasks[ind].bBusy = true;

    switch (m_Param.Angle)
    {
    case 180:
        m_pTasks[ind].pProcessor = new Rotator180;
        CHECK_POINTER(m_pTasks[ind].pProcessor, MFX_ERR_MEMORY_ALLOC);
        break;
    default:
        return MFX_ERR_UNSUPPORTED;
    }
    
    m_pTasks[ind].pProcessor->Init(surface_in, surface_out);
    
    *task = (mfxThreadTask)&m_pTasks[ind];    

    return MFX_ERR_NONE;
}

mfxStatus Rotate::mfxExecute(mfxThreadTask task, mfxU32 thread_id, mfxU32 call_count)
{    
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(m_pmfxCore, MFX_ERR_NOT_INITIALIZED);  

    mfxStatus sts = MFX_ERR_NONE;
    RotateTask *current_task = (RotateTask *)task;    

    // 0,...,NumChunks - 2 calls return TASK_WORKING, NumChunks - 1,.. return TASK_DONE
    if (call_count < m_NumChunks)
    {
        // there's data to process
        sts = current_task->pProcessor->Process(&m_pChunks[call_count]);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);
        // last call?
        sts = ((m_NumChunks - 1) == call_count) ? MFX_TASK_DONE : MFX_TASK_WORKING;
    }
    else
    {
        // no data to process
        sts =  MFX_TASK_DONE;
    }

    return sts;        
}

mfxStatus Rotate::mfxFreeResources(mfxThreadTask task, mfxStatus sts)
{
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED); 
    CHECK_POINTER(m_pmfxCore, MFX_ERR_NOT_INITIALIZED);  

    RotateTask *current_task = (RotateTask *)task;
    
    m_pmfxCore->DecreaseReference(m_pmfxCore->pthis, &(current_task->In->Data));
    m_pmfxCore->DecreaseReference(m_pmfxCore->pthis, &(current_task->Out->Data));
    current_task->bBusy = false;
    SAFE_DELETE(current_task->pProcessor);

    return MFX_ERR_NONE;
}

/* Custom methods */
mfxStatus Rotate::Init(RotateParam *par)
{
    CHECK_POINTER(par, MFX_ERR_NULL_PTR);     

    // check validity of parameters
    mfxStatus sts = CheckParam(par);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    m_Param = *par;
    m_pTasks = new RotateTask [m_Param.MaxNumTasks];
    CHECK_POINTER(m_pTasks, MFX_ERR_MEMORY_ALLOC);
    memset(m_pTasks, 0, sizeof(RotateTask) * m_Param.MaxNumTasks);

    m_NumChunks = m_Param.MaxThreadNum;
    m_pChunks = new DataChunk [m_NumChunks];
    CHECK_POINTER(m_pChunks, MFX_ERR_MEMORY_ALLOC);
    memset(m_pChunks, 0, sizeof(DataChunk) * m_NumChunks);

    // divide frame into data chunks
    mfxU32 num_lines_in_chunk = m_Param.In.CropH / m_NumChunks; // integer division
    mfxU32 remainder_lines = m_Param.In.CropH % m_NumChunks; // get remainder
    // remaining lines are distributed among first chunks (+ extra 1 line each)
    for (mfxU32 i = 0; i < m_NumChunks; i++)
    {
        m_pChunks[i].StartLine = (i == 0) ? 0 : m_pChunks[i-1].EndLine + 1; 
        m_pChunks[i].EndLine = (i < remainder_lines) ? (i + 1) * num_lines_in_chunk : (i + 1) * num_lines_in_chunk - 1;
    }

    m_bInited = true;

    return MFX_ERR_NONE;
}

void Rotate::Close()
{
    memset(&m_Param, 0, sizeof(RotateParam));

    SAFE_DELETE_ARRAY(m_pTasks);   

    m_bInited = false;
}

mfxStatus Rotate::GetOutputFrameSize(mfxU16 srcw, mfxU16 srch, mfxU32 angle, mfxU16 *dstw, mfxU16 *dsth)
{
    CHECK_ERROR(srcw, 0, MFX_ERR_UNSUPPORTED);
    CHECK_ERROR(srch, 0, MFX_ERR_UNSUPPORTED);
    CHECK_POINTER(dstw, MFX_ERR_NULL_PTR);
    CHECK_POINTER(dsth, MFX_ERR_NULL_PTR);

    switch (angle)
    {
    case 180:
        *dstw = srcw;
        *dsth = srch;
        break;
    default:
        return MFX_ERR_UNSUPPORTED;
    }

    return MFX_ERR_NONE;
}

/* Internal methods */
mfxU32 Rotate::FindFreeTaskIdx()
{   
    mfxU32 i;
    for (i = 0; i < m_Param.MaxNumTasks; i++)
    {
        if (false == m_pTasks[i].bBusy)
        {
            break;
        }
    }

    return i;
}

mfxStatus Rotate::CheckParam(RotateParam *pParam)
{
    CHECK_POINTER(pParam, MFX_ERR_NULL_PTR);      

    // check validity of output frame size
    mfxU16 dstw = 0, dsth = 0;
    mfxStatus sts = GetOutputFrameSize(pParam->In.CropW, pParam->In.CropH, pParam->Angle, &dstw, &dsth);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    if (pParam->Out.CropW != dstw || pParam->Out.CropH != dsth)
    {
        return MFX_ERR_INVALID_VIDEO_PARAM;
    }    

    // only NV12 color format is supported
    if (MFX_FOURCC_NV12 != pParam->In.FourCC || MFX_FOURCC_NV12 != pParam->Out.FourCC)
    {
        return MFX_ERR_UNSUPPORTED;
    }    

    return MFX_ERR_NONE;
}

mfxStatus Rotate::CheckInOutFrameInfo(mfxFrameInfo *pIn, mfxFrameInfo *pOut)
{
    CHECK_POINTER(pIn, MFX_ERR_NULL_PTR);
    CHECK_POINTER(pOut, MFX_ERR_NULL_PTR);

    if (pIn->CropW != m_Param.In.CropW || pIn->CropH != m_Param.In.CropH || 
        pIn->FourCC != m_Param.In.FourCC ||
        pOut->CropW != m_Param.Out.CropW || pOut->CropH != m_Param.Out.CropH || 
        pOut->FourCC != m_Param.Out.FourCC)
    {
        return MFX_ERR_INVALID_VIDEO_PARAM;
    }

    return MFX_ERR_NONE;
}

mfxStatus Rotate::CheckFrameData(mfxFrameSurface1 * pSurface)
{
    CHECK_POINTER(pSurface, MFX_ERR_NULL_PTR);    

    switch (pSurface->Info.FourCC)
    {        
    case MFX_FOURCC_NV12:
        if (!pSurface->Data.Y || !pSurface->Data.UV)
            return MFX_ERR_NULL_PTR;
        break;    
    default:
        break;
    }

    if (pSurface->Data.Pitch > 0x7FFF)
        return MFX_ERR_UNDEFINED_BEHAVIOR;
   
    return MFX_ERR_NONE;
}

/* Processor class implementation */
Processor::Processor() : m_pIn(NULL), m_pOut(NULL)
{
}

Processor::~Processor()
{
}

mfxStatus Processor::Init(mfxFrameSurface1 *frame_in, mfxFrameSurface1 *frame_out)
{
    CHECK_POINTER(frame_in, MFX_ERR_NULL_PTR);
    CHECK_POINTER(frame_out, MFX_ERR_NULL_PTR);

    m_pIn = frame_in;
    m_pOut = frame_out;    

    return MFX_ERR_NONE;        
}

/* 180 degrees rotator class implementation */
Rotator180::Rotator180() : Processor()
{
}

Rotator180::~Rotator180()
{
}

mfxStatus Rotator180::Process(DataChunk *chunk)
{
    CHECK_POINTER(chunk, MFX_ERR_NULL_PTR);

    mfxU32 i, j, in_pitch, out_pitch, h, w;

    in_pitch = m_pIn->Data.Pitch;
    out_pitch = m_pOut->Data.Pitch;
    h = m_pIn->Info.CropH;
    w = m_pIn->Info.CropW;
    mfxU8 *in_luma = m_pIn->Data.Y + m_pIn->Info.CropY * in_pitch + m_pIn->Info.CropX;
    mfxU8 *out_luma = m_pOut->Data.Y + m_pOut->Info.CropY * out_pitch + m_pOut->Info.CropX; 

    mfxU8 *in_chroma = m_pIn->Data.VU + m_pIn->Info.CropY / 2 * in_pitch + m_pIn->Info.CropX;
    mfxU8 *out_chroma = m_pOut->Data.VU + m_pOut->Info.CropY / 2 * out_pitch + m_pOut->Info.CropX; 

    mfxU8 *cur_line = 0; // current line in the destination image
    
    switch (m_pIn->Info.FourCC)
    {
    case MFX_FOURCC_NV12: 
          for (i = chunk->StartLine; i <= chunk->EndLine; i++)
          {
              // rotate Y plane
              cur_line = out_luma + (h-1-i) * out_pitch;

              // i-th line images into h-1-i-th line, w bytes in line
              memcpy(cur_line,  in_luma + i * in_pitch, w);        
              
              // mirror line's elements with respect to the middle element, element=Yj                          
              for (j = 0; j < w / 2; j++)
              {              
                  SWAP_BYTES(cur_line[j], cur_line[w-1-j]); 
              }              

              // rotate VU plane, contains h/2 lines
              cur_line = out_chroma + (h/2-1-i/2) * out_pitch;

              // i-th line images into h-1-i-th line, w bytes in line
              memcpy(cur_line,  in_chroma + i/2 * in_pitch, w);        

              // mirror line's elements with respect to the middle element, element=VjUj
              for (j = 0; j < w/2 - 1; j = j + 2)
              {              
                  SWAP_BYTES(cur_line[j], cur_line[w-1-j-1]); // 0 -> -1                  
                  SWAP_BYTES(cur_line[j+1], cur_line[w-1-j]); // 1 -> -0                     
              }             
          }
          break;
    default:
        MFX_ERR_UNSUPPORTED;
    }    

    return MFX_ERR_NONE;
}

