//
//               INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in accordance with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//

#include "pipeline_encode.h"
#include "pipeline_user.h"

void PrintHelp(TCHAR *strAppName, TCHAR *strErrorMessage)
{
    if (strErrorMessage)
    {
        _tprintf(_T("Error: %s\n\n"), strErrorMessage);
    }
    else
    {
        _tprintf(_T("Intel(R) Media SDK Encoding Sample\n"));
    }
    _tprintf(_T("Usage: %s h264|mpeg2 [Options] -i InputYUVFile -o OutputEncodedFile -w width -h height\n"), strAppName);    
    _tprintf(_T("Options: \n"));
    _tprintf(_T("   [-nv12] - input is in NV12 color format, if not specified YUV420 is expected\n"));  
    _tprintf(_T("   [-tff|bff] - input stream is interlaced, top|bottom fielf first, if not specified progressive is expected\n"));      
    _tprintf(_T("   [-f frameRate] - video frame rate (frames per second)\n"));
    _tprintf(_T("   [-b bitRate] - encoded bit rate (Kbits per second)\n"));
    _tprintf(_T("   [-u speed|quality|balanced] - target usage\n"));
    _tprintf(_T("   [-t numThreads] - number of threads; default value 0 \n"));
    _tprintf(_T("   [-dstw] - destination picture width, invokes VPP resizing\n")); 
    _tprintf(_T("   [-dsth] - destination picture height, invokes VPP resizing\n")); 
    _tprintf(_T("   [-hw] - use platform specific SDK implementation, if not specified software implementation is used\n"));
#ifdef D3D_SURFACES_SUPPORT
    _tprintf(_T("   [-d3d] - work with d3d surfaces\n"));
#endif
    _tprintf(_T("   [-angle] - enables rotation before encoding, requires NV12 input. Options -tff|bff, -dstw, -dsth, -d3d are not effective together with this one, -nv12 is required.\n"));
	_tprintf(_T("   [-mux] - mux stream into container (mp4/mpeg)\n"));
    _tprintf(_T("\n"));
}

#define GET_OPTION_POINTER(PTR)         \
{                                       \
    if (2 == _tcslen(strInput[i]))      \
    {                                   \
        i++;                            \
        if (strInput[i][0] == _T('-'))  \
        {                               \
            i = i - 1;                  \
        }                               \
        else                            \
        {                               \
            PTR = strInput[i];          \
        }                               \
    }                                   \
    else                                \
    {                                   \
        PTR = strInput[i] + 2;          \
    }                                   \
}

mfxStatus ParseInputString(TCHAR* strInput[], mfxU8 nArgNum, sInputParams* pParams)
{
    TCHAR* strArgument = _T("");    

    if (1 == nArgNum)
    {
        PrintHelp(strInput[0], NULL);
        return MFX_ERR_UNSUPPORTED;
    }

    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);
    ZERO_MEMORY(*pParams);

    // parse command line parameters
    for (mfxU8 i = 1; i < nArgNum; i++)
    {
        CHECK_POINTER(strInput[i], MFX_ERR_NULL_PTR);

        if (_T('-') != strInput[i][0])
        {
            if (0 == _tcscmp(strInput[i], _T("h264")))
            {
                pParams->CodecId = MFX_CODEC_AVC;
            }
            else if (0 == _tcscmp(strInput[i], _T("mpeg2")))
            {
                pParams->CodecId = MFX_CODEC_MPEG2;
            }
            else
            {
                PrintHelp(strInput[0], _T("Unknown codec"));
                return MFX_ERR_UNSUPPORTED;
            }
            continue;
        }

        // process multi-character options
        if (0 == _tcscmp(strInput[i], _T("-dstw")))
        {
            i++;
            _stscanf_s(strInput[i], _T("%hd"), &pParams->nDstWidth);            
        }
        else if (0 == _tcscmp(strInput[i], _T("-dsth")))
        {
            i++;
            _stscanf_s(strInput[i], _T("%hd"), &pParams->nDstHeight);
        }
        else if (0 == _tcscmp(strInput[i], _T("-hw")))
        {
            pParams->bUseHWLib = true;
        }
        else if (0 == _tcscmp(strInput[i], _T("-nv12")))
        {
            pParams->ColorFormat = MFX_FOURCC_NV12;
        }
        else if (0 == _tcscmp(strInput[i], _T("-tff")))
        {
            pParams->nPicStruct = MFX_PICSTRUCT_FIELD_TFF;
        }
        else if (0 == _tcscmp(strInput[i], _T("-bff")))
        {
            pParams->nPicStruct = MFX_PICSTRUCT_FIELD_BFF;
        }
        else if (0 == _tcscmp(strInput[i], _T("-angle")))
        {
            i++;
            _stscanf_s(strInput[i], _T("%hd"), &pParams->nRotationAngle);            
        }
#ifdef D3D_SURFACES_SUPPORT
        else if (0 == _tcscmp(strInput[i], _T("-d3d")))
        {
            pParams->bd3dAlloc = true;
        }
#endif
        else if (0 == _tcscmp(strInput[i], _T("-mux")))
        {
            pParams->bMux = true;
        }
        else // 1-character options
        {
            switch (strInput[i][1])
            {
            case _T('u'):
                GET_OPTION_POINTER(strArgument);
                pParams->nTargetUsage = StrToTargetUsage(strArgument);
                break;
            case _T('w'):
                GET_OPTION_POINTER(strArgument);
                _stscanf_s(strArgument, _T("%hd"), &pParams->nWidth);
                break;
            case _T('h'):
                GET_OPTION_POINTER(strArgument);
                _stscanf_s(strArgument, _T("%hd"), &pParams->nHeight);
                break;
            case _T('f'):
                GET_OPTION_POINTER(strArgument);
                _stscanf_s(strArgument, _T("%lf"), &pParams->dFrameRate);
                break;
            case _T('b'):
                GET_OPTION_POINTER(strArgument);
                _stscanf_s(strArgument, _T("%hd"), &pParams->nBitRate);
                break;
            case _T('t'):
                GET_OPTION_POINTER(strArgument);
                _stscanf_s(strArgument, _T("%hd"), &pParams->nThreads);
                break;
            case _T('i'):
                GET_OPTION_POINTER(strArgument);
                _tcscpy_s(pParams->strSrcFile, strArgument);
                break;
            case _T('o'):
                GET_OPTION_POINTER(strArgument);
                _tcscpy_s(pParams->strDstFile, strArgument);
                break;
            case _T('?'):
                PrintHelp(strInput[0], NULL);
                return MFX_ERR_UNSUPPORTED;
            default:
                PrintHelp(strInput[0], _T("Unknown options"));
            }
        }
    }

    // check if all mandatory parameters were set
    if (0 == _tcslen(pParams->strSrcFile))
    {
        PrintHelp(strInput[0], _T("Source file name not found"));
        return MFX_ERR_UNSUPPORTED;
    };

    if (0 == _tcslen(pParams->strDstFile))
    {
        PrintHelp(strInput[0], _T("Destination file name not found"));
        return MFX_ERR_UNSUPPORTED;
    };

    if (0 == pParams->nWidth || 0 == pParams->nHeight)
    {
        PrintHelp(strInput[0], _T("-w, -h must be specified"));
        return MFX_ERR_UNSUPPORTED;
    }

    if (MFX_CODEC_MPEG2 != pParams->CodecId && MFX_CODEC_AVC != pParams->CodecId)
    {
        PrintHelp(strInput[0], _T("Unknown codec"));
        return MFX_ERR_UNSUPPORTED;
    }

    // set default values for optional parameters that were not set or were set incorrectly
    if (MFX_TARGETUSAGE_BEST_QUALITY != pParams->nTargetUsage && MFX_TARGETUSAGE_BEST_SPEED != pParams->nTargetUsage)
    {
        pParams->nTargetUsage = MFX_TARGETUSAGE_BALANCED;
    }
    
    if (pParams->dFrameRate <= 0)
    {
        pParams->dFrameRate = 30;
    }    

    // if no destination picture width or height wasn't specified set it to the source picture size
    if (pParams->nDstWidth == 0)
    {
        pParams->nDstWidth = pParams->nWidth;
    }

    if (pParams->nDstHeight == 0)
    {
        pParams->nDstHeight = pParams->nHeight;
    }

    // calculate default bitrate based on the resolution (a parameter for encoder, so Dst resolution is used)
    if (pParams->nBitRate == 0)
    {        
        pParams->nBitRate = CalculateDefaultBitrate(pParams->CodecId, pParams->nTargetUsage, pParams->nDstWidth,
            pParams->nDstHeight, pParams->dFrameRate);         
    }    

    // if nv12 option wasn't specified we expect input YUV file in YUV420 color format
    if (!pParams->ColorFormat)
    {
        pParams->ColorFormat = MFX_FOURCC_YV12;
    }

    if (!pParams->nPicStruct)
    {
        pParams->nPicStruct = MFX_PICSTRUCT_PROGRESSIVE;
    }

    if (pParams->nRotationAngle != 0 && pParams->nRotationAngle != 180)
    {
        PrintHelp(strInput[0], _T("Angles other than 180 degrees are not supported."));
        return MFX_ERR_UNSUPPORTED; // other than 180 are not supported 
    }  

    // not all options are supported if rotate plugin is enabled
    if (pParams->nRotationAngle == 180) 
    {
        if (MFX_FOURCC_NV12 != pParams->ColorFormat)
        {
            PrintHelp(strInput[0], _T("Rotation plugin requires NV12 input. Please specify -nv12 option."));
            return MFX_ERR_UNSUPPORTED;
        }
        pParams->nPicStruct = MFX_PICSTRUCT_PROGRESSIVE;        
        pParams->nDstWidth = pParams->nWidth;
        pParams->nDstHeight = pParams->nHeight;       
        pParams->bd3dAlloc = false;        
    }

    return MFX_ERR_NONE;
}

int _tmain(int argc, TCHAR *argv[])
{  
    sInputParams        Params;   // input parameters from command line
    std::auto_ptr<CEncodingPipeline>  pPipeline; 

    mfxStatus sts = MFX_ERR_NONE; // return value check

    sts = ParseInputString(argv, (mfxU8)argc, &Params);
    CHECK_RESULT(sts, MFX_ERR_NONE, 1); 

    pPipeline.reset((Params.nRotationAngle) ? new CUserPipeline : new CEncodingPipeline); 
    CHECK_POINTER(pPipeline.get(), MFX_ERR_MEMORY_ALLOC);

    sts = pPipeline->Init(&Params);
    CHECK_RESULT(sts, MFX_ERR_NONE, 1);   

    _tprintf(_T("Processing started\n"));

    for (;;)
    {
        sts = pPipeline->Run();

        if (MFX_ERR_DEVICE_LOST == sts || MFX_ERR_DEVICE_FAILED == sts)
        {            
            _tprintf(_T("\nERROR: Hardware device was lost or returned an unexpected error. Recovering...\n"));
            sts = pPipeline->ResetDevice();
            CHECK_RESULT(sts, MFX_ERR_NONE, 1);         

            sts = pPipeline->ResetMFXComponents(&Params);
            CHECK_RESULT(sts, MFX_ERR_NONE, 1);
            continue;
        }        
        else
        {            
            CHECK_RESULT(sts, MFX_ERR_NONE, 1);
            break;
        }
    }    

    pPipeline->Close();  
    _tprintf(_T("\nProcessing finished\n"));    
    
    return 0;
}
