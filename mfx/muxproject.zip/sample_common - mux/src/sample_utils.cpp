/* ////////////////////////////////////////////////////////////////////////////// */
/*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
*/
#include <math.h>
#include <windows.h>

#include "sample_defs.h"
#include "sample_utils.h"

CSmplYUVReader::CSmplYUVReader()
{
    m_bInited = false;
    m_fSource = NULL;
    m_ColorFormat = MFX_FOURCC_YV12;
}

mfxStatus CSmplYUVReader::Init(const TCHAR *strFileName, mfxU32 ColorFormat)
{
    Close();

    CHECK_ERROR(_tclen(strFileName), 0, MFX_ERR_NULL_PTR);

    //open source YUV file
    _tfopen_s(&m_fSource, strFileName, _T("rb"));
    CHECK_POINTER(m_fSource, MFX_ERR_NULL_PTR);

    //set init state to true in case of success
    m_bInited = true;

    if (ColorFormat == MFX_FOURCC_NV12 || ColorFormat == MFX_FOURCC_YV12)
    {
        m_ColorFormat = ColorFormat;
    }
    else
    {
        return MFX_ERR_UNSUPPORTED;    
    }
    
    return MFX_ERR_NONE;
}

CSmplYUVReader::~CSmplYUVReader()
{
    Close();
}

void CSmplYUVReader::Close()
{
    if (m_fSource)
    {
        fclose(m_fSource);
        m_fSource = NULL;

    }

    m_bInited = false;
}

mfxStatus CSmplYUVReader::LoadNextFrame(mfxFrameSurface1* pSurface)
{
    // check if reader is initialized
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(pSurface, MFX_ERR_NULL_PTR);

    mfxU32 nBytesRead;
    mfxU16 w, h, i, pitch;
    mfxU8 *ptr, *ptr2;
    mfxFrameInfo* pInfo = &pSurface->Info;
    mfxFrameData* pData = &pSurface->Data;

    // this reader supports only NV12 mfx surfaces for code transparency, 
    // other formats may be added if application requires such functionality
    if (MFX_FOURCC_NV12 != pInfo->FourCC && MFX_FOURCC_YV12 != pInfo->FourCC)  
    {
        return MFX_ERR_UNSUPPORTED;
    }

    if (pInfo->CropH > 0 && pInfo->CropW > 0) 
    {
        w = pInfo->CropW;
        h = pInfo->CropH;
    } 
    else 
    {
        w = pInfo->Width;
        h = pInfo->Height;
    }

    pitch = pData->Pitch;
    ptr = pData->Y + pInfo->CropX + pInfo->CropY * pData->Pitch;

    // read luminance plane
    for(i = 0; i < h; i++) 
    {
        nBytesRead = (mfxU32)fread(ptr + i * pitch, 1, w, m_fSource);
        if (w != nBytesRead)
        {
            return MFX_ERR_MORE_DATA;
        }
    }

    // read chroma planes
    switch (m_ColorFormat) // color format of data in the input file
    {
    case MFX_FOURCC_YV12: // YUV420 is implied  
        switch (pInfo->FourCC)
        {
        case MFX_FOURCC_NV12:

            mfxU8 buf[2048]; // maximum supported chroma width for nv12
            mfxU32 j;
            w /= 2;
            h /= 2;            
            ptr = pData->UV + pInfo->CropX + (pInfo->CropY / 2) * pitch;
            if (w > 2048)
            {
                return MFX_ERR_UNSUPPORTED;
            }
            // load U
            for (i = 0; i < h; i++) 
            {
                nBytesRead = (mfxU32)fread(buf, 1, w, m_fSource);
                if (w != nBytesRead)
                {
                    return MFX_ERR_MORE_DATA;
                }
                for (j = 0; j < w; j++)
                {
                    ptr[i * pitch + j * 2] = buf[j];
                }
            }
            // load V
            for (i = 0; i < h; i++) 
            {
                nBytesRead = (mfxU32)fread(buf, 1, w, m_fSource);
                if (w != nBytesRead)
                {
                    return MFX_ERR_MORE_DATA;
                }
                for (j = 0; j < w; j++)
                {
                    ptr[i * pitch + j * 2 + 1] = buf[j];
                }
            }
        
            break;
        case MFX_FOURCC_YV12:
            w /= 2;
            h /= 2;
            pitch /= 2;

            ptr  = pData->U + (pInfo->CropX / 2) + (pInfo->CropY / 2) * pitch;
            ptr2 = pData->V + (pInfo->CropX / 2) + (pInfo->CropY / 2) * pitch;

            for(i = 0; i < h; i++) 
            {
                nBytesRead = (mfxU32)fread(ptr + i * pitch, 1, w, m_fSource);
                if (w != nBytesRead)
                {
                    return MFX_ERR_MORE_DATA;
                }
            }
            for(i = 0; i < h; i++) 
            {
                nBytesRead = (mfxU32)fread(ptr2 + i * pitch, 1, w, m_fSource);
                if (w != nBytesRead)
                {
                    return MFX_ERR_MORE_DATA;
                }
            }  

            break;
        default:
            return MFX_ERR_UNSUPPORTED;
            }
        break;
    case MFX_FOURCC_NV12:   
        h /= 2;
        ptr  = pData->UV + pInfo->CropX + (pInfo->CropY / 2) * pitch;
        for(i = 0; i < h; i++) 
        {
            nBytesRead = (mfxU32)fread(ptr + i * pitch, 1, w, m_fSource);
            if (w != nBytesRead)
            {
                return MFX_ERR_MORE_DATA;
            }
        }             
         
        break;
    default:
        return MFX_ERR_UNSUPPORTED;
    }   

    return MFX_ERR_NONE;    
}

CSmplBitstreamWriter::CSmplBitstreamWriter()
{
    m_fSource = NULL;
    m_bInited = false;
    m_nProcessedFramesNum = 0;
}

CSmplBitstreamWriter::~CSmplBitstreamWriter()
{
    Close();
}

void CSmplBitstreamWriter::Close()
{
    if (m_fSource)
    {
        fclose(m_fSource);
        m_fSource = NULL;
    }

    m_bInited = false;
    m_nProcessedFramesNum = 0;
}

mfxStatus CSmplBitstreamWriter::Init(const TCHAR *strFileName)
{
    CHECK_POINTER(strFileName, MFX_ERR_NULL_PTR);
    CHECK_ERROR(_tcslen(strFileName), 0, MFX_ERR_NOT_INITIALIZED);

    Close();

    //init file to write encoded data
    _tfopen_s(&m_fSource, strFileName, _T("wb+"));
    CHECK_POINTER(m_fSource, MFX_ERR_NULL_PTR);

    //set init state to true in case of success
    m_bInited = true;
    return MFX_ERR_NONE;
}

mfxStatus CSmplBitstreamWriter::WriteNextFrame(mfxBitstream *pMfxBitstream, bool isPrint)
{    
    // check if writer is initialized
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(pMfxBitstream, MFX_ERR_NULL_PTR);

    mfxU32 nBytesWritten = 0;

    nBytesWritten = (mfxU32)fwrite(pMfxBitstream->Data + pMfxBitstream->DataOffset, 1, pMfxBitstream->DataLength, m_fSource);
    CHECK_NOT_EQUAL(nBytesWritten, pMfxBitstream->DataLength, MFX_ERR_UNDEFINED_BEHAVIOR);   

    // mark that we don't need bit stream data any more
    pMfxBitstream->DataLength = 0;

    m_nProcessedFramesNum++;

    // print encoding progress to console every certain number of frames (not to affect performance too much)
    if (isPrint && 0 == (m_nProcessedFramesNum - 1) % 100)
    {
        _tcprintf(_T("Frame number: %hd\r"), m_nProcessedFramesNum); 
    }    

    return MFX_ERR_NONE;
}


MuxWriter::MuxWriter():
	m_pMuxer(NULL),
	m_pMuxerParams(NULL),
	m_videoTrackID(0)
{
}

MuxWriter::~MuxWriter()
{
    Close();
}

void MuxWriter::Close()
{
	UMC::Status umcRes = UMC::UMC_OK;
	if(m_pMuxer){
		umcRes = m_pMuxer->PutEndOfStream(m_videoTrackID);
	}
	//CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);

	SAFE_DELETE(m_pMuxer);
	SAFE_DELETE(m_pMuxerParams);

    m_bInited = false;
    m_nProcessedFramesNum = 0;
}

mfxStatus MuxWriter::Init(	const TCHAR *strFileName,
							const mfxU16 nWidth,
							const mfxU16 nHeight,
							const mfxF64 dFrameRate,
							const mfxU16 nBitRate,
							const mfxU32 nCodecId)
{
    CHECK_POINTER(strFileName, MFX_ERR_NULL_PTR);
    CHECK_ERROR(_tcslen(strFileName), 0, MFX_ERR_NOT_INITIALIZED);

	UMC::Status umcRes = UMC::UMC_OK;

	Close();

	if(MFX_CODEC_AVC == nCodecId)
	{
		m_pMuxer		= new UMC::MP4Muxer();
		m_pMuxerParams	= new UMC::MuxerParams();

		m_videoInfo.stream_type			= UMC::H264_VIDEO;
		m_pMuxerParams->m_SystemType	= UMC::MPEG4_SYSTEM_STREAM;
	}
	else if(MFX_CODEC_MPEG2 == nCodecId)
	{
		m_pMuxer		= new UMC::MPEG2Muxer();
		m_pMuxerParams	= new UMC::MPEG2MuxerParams();

		m_videoInfo.stream_type			= UMC::MPEG2_VIDEO;
		m_pMuxerParams->m_SystemType	= UMC::MPEG2_PURE_VIDEO_STREAM;
	}
	else
		return MFX_ERR_UNSUPPORTED;

	// Initialize file writer
	char tempStr[UMC::MAXIMUM_PATH];
	wcstombs(tempStr, strFileName, UMC::MAXIMUM_PATH);
	strcpy((char *)m_fwp.m_file_name, tempStr);
	m_fwp.m_portion_size = 0;

    umcRes = m_writer.Init(&m_fwp);
	CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);

	// Video info
	m_videoInfo.clip_info.height	= nHeight;
	m_videoInfo.clip_info.width		= nWidth;
	m_videoInfo.bitrate				= nBitRate;
	m_videoInfo.framerate			= dFrameRate;
	m_videoInfo.streamPID			= UMC::IdBank::NO_ID;

	// Muxer config
	m_pMuxerParams->m_lpDataWriter				= &m_writer;
	m_pMuxerParams->m_nNumberOfTracks			= 1;
	m_pMuxerParams->pTrackParams				= new UMC::TrackParams[m_pMuxerParams->m_nNumberOfTracks];;
	m_pMuxerParams->pTrackParams[0].type		= UMC::VIDEO_TRACK;
	m_pMuxerParams->pTrackParams[0].info.video	= &m_videoInfo;
	m_pMuxerParams->pTrackParams[0].bufferParams.m_prefOutputBufferSize = 1000000;
	m_pMuxerParams->pTrackParams[0].bufferParams.m_prefInputBufferSize	= 1000000;
	m_pMuxerParams->pTrackParams[0].bufferParams.m_numberOfFrames		= 30;
	

	m_frameDuration = (Ipp64f)1/dFrameRate;

	// muxer init
	umcRes = m_pMuxer->Init(m_pMuxerParams);
	CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);

	// Initial alloc of memory for muxer data buffer. will be extended runtime if needed
	m_videoData.Alloc(400000);

    // Set init state to true in case of success
    m_bInited = true;

    return MFX_ERR_NONE;
}

mfxStatus MuxWriter::WriteNextFrame(mfxBitstream *pMfxBitstream, bool isPrint)
{    
    // check if writer is initialized
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(pMfxBitstream, MFX_ERR_NULL_PTR);

	UMC::Status umcRes = UMC::UMC_OK;


	umcRes = m_videoData.SetDataSize(pMfxBitstream->DataLength);
	// If setdatasize fails try to allocate larger buffer
	if(UMC::UMC_OK != umcRes) {
		umcRes = m_videoData.Alloc(pMfxBitstream->DataLength);
		if (UMC::UMC_OK == umcRes)
			umcRes = m_videoData.SetDataSize(pMfxBitstream->DataLength);
	}
	CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);

	assert(m_videoData.m_nBufferSize == pMfxBitstream->DataLength);
	memcpy(m_videoData.GetDataPointer(), pMfxBitstream->Data + pMfxBitstream->DataOffset, pMfxBitstream->DataLength);

	// Muxer requires time stamps
	Ipp64f tss = m_nProcessedFramesNum * m_frameDuration + m_frameDuration; // Adding timestamp offset to oblige WMP
	umcRes = m_videoData.SetTime(tss, tss + m_frameDuration);
	CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);

	umcRes = m_pMuxer->PutVideoData(&m_videoData, 0); //m_videoTrackID);
	CHECK_NOT_EQUAL(umcRes, UMC::UMC_OK, MFX_ERR_UNKNOWN);


    // mark that we don't need bit stream data any more
    pMfxBitstream->DataLength = 0;

    m_nProcessedFramesNum++;

    // print encoding progress to console every certain number of frames (not to affect performance too much)
    if (isPrint && 0 == (m_nProcessedFramesNum - 1) % 100)
    {
        _tcprintf(_T("Frame number: %hd\r"), m_nProcessedFramesNum); 
    }    

    return MFX_ERR_NONE;
}


CSmplBitstreamReader::CSmplBitstreamReader()
{
    m_fSource = NULL;
    m_bInited = false;
}

CSmplBitstreamReader::~CSmplBitstreamReader()
{
    Close();
}

void CSmplBitstreamReader::Close()
{
    if (m_fSource)
    {
        fclose(m_fSource);
        m_fSource = NULL;
    }

    m_bInited = false;
}

mfxStatus CSmplBitstreamReader::Init(const TCHAR *strFileName)
{
    CHECK_POINTER(strFileName, MFX_ERR_NULL_PTR);
    CHECK_ERROR(_tcslen(strFileName), 0, MFX_ERR_NOT_INITIALIZED);

    Close();

    //open file to read input stream
    _tfopen_s(&m_fSource, strFileName, _T("rb"));
    CHECK_POINTER(m_fSource, MFX_ERR_NULL_PTR);

    m_bInited = true;
    return MFX_ERR_NONE;
}

mfxStatus CSmplBitstreamReader::ReadNextFrame(mfxBitstream *pBS)
{
    CHECK_POINTER(pBS, MFX_ERR_NULL_PTR);
    CHECK_ERROR(m_bInited, false, MFX_ERR_NOT_INITIALIZED);

    mfxU32 nBytesRead = 0;

    memcpy(pBS->Data, pBS->Data + pBS->DataOffset, pBS->DataLength);
    pBS->DataOffset = 0;
    nBytesRead = (mfxU32)fread(pBS->Data + pBS->DataLength, 1, pBS->MaxLength - pBS->DataLength, m_fSource);
    
    if (0 == nBytesRead)
    {
        return MFX_ERR_MORE_DATA;
    }     

    pBS->DataLength += nBytesRead;    

    return MFX_ERR_NONE;
}

CSmplYUVWriter::CSmplYUVWriter()
{
    m_bInited = false;
    m_fDest = NULL;
};

mfxStatus CSmplYUVWriter::Init(const TCHAR *strFileName)
{
    CHECK_POINTER(strFileName, MFX_ERR_NULL_PTR);
    CHECK_ERROR(_tcslen(strFileName), 0, MFX_ERR_NOT_INITIALIZED);    

    Close();  

    //open file to write decoded data
    _tfopen_s(&m_fDest, strFileName, _T("wb"));
    CHECK_POINTER(m_fDest, MFX_ERR_NULL_PTR);

    m_bInited = true;

    return MFX_ERR_NONE;
}

CSmplYUVWriter::~CSmplYUVWriter()
{
    Close();
}

void CSmplYUVWriter::Close()
{    
    if (m_fDest)
    {
        fclose(m_fDest);
        m_fDest = NULL;
    }    

    m_bInited = false;
}

mfxStatus CSmplYUVWriter::WriteNextFrame(mfxFrameSurface1 *pSurface)
{
    CHECK_ERROR(m_bInited, false,   MFX_ERR_NOT_INITIALIZED);
    CHECK_POINTER(pSurface,         MFX_ERR_NULL_PTR);

    mfxFrameInfo *pInfo = &pSurface->Info;
    mfxFrameData *pData = &pSurface->Data;
    CHECK_POINTER(pData, MFX_ERR_NULL_PTR);

    mfxU32 i, j, h, w;   

    switch (pInfo->FourCC)
    {
    case MFX_FOURCC_NV12:
        for (i = 0; i < pInfo->CropH; i++)
        {
            CHECK_NOT_EQUAL(
                fwrite(pData->Y + (pInfo->CropY * pData->Pitch + pInfo->CropX)+ i * pData->Pitch, 1, pInfo->CropW, m_fDest), 
                pInfo->CropW, MFX_ERR_UNDEFINED_BEHAVIOR);
        }

        h = pInfo->CropH / 2;
        w = pInfo->CropW;
        for (i = 0; i < h; i++)
        {
            for (j = 0; j < w; j += 2)
            {
                CHECK_NOT_EQUAL(
                    fwrite(pData->UV + (pInfo->CropY * pData->Pitch / 2 + pInfo->CropX) + i * pData->Pitch + j, 1, 1, m_fDest),
                    1, MFX_ERR_UNDEFINED_BEHAVIOR);
            }
        }
        for (i = 0; i < h; i++)
        {
            for (j = 1; j < w; j += 2)
            {
                CHECK_NOT_EQUAL(
                    fwrite(pData->UV + (pInfo->CropY * pData->Pitch / 2 + pInfo->CropX)+ i * pData->Pitch + j, 1, 1, m_fDest),
                    1, MFX_ERR_UNDEFINED_BEHAVIOR);
            }
        }

        break;

    default:
        return MFX_ERR_UNSUPPORTED;
    }

    return MFX_ERR_NONE;
}

mfxStatus ConvertFrameRate(mfxF64 dFrameRate, mfxU32* pnFrameRateExtN, mfxU32* pnFrameRateExtD)
{
    CHECK_POINTER(pnFrameRateExtN, MFX_ERR_NULL_PTR);
    CHECK_POINTER(pnFrameRateExtD, MFX_ERR_NULL_PTR);

    mfxU32 fr; 

    fr = (mfxU32)(dFrameRate + .5);

    if (fabs(fr - dFrameRate) < 0.0001) 
    {
        *pnFrameRateExtN = fr;
        *pnFrameRateExtD = 1;
        return MFX_ERR_NONE;
    }

    fr = (mfxU32)(dFrameRate * 1.001 + .5);

    if (fabs(fr * 1000 - dFrameRate * 1001) < 10) 
    {
        *pnFrameRateExtN = fr * 1000;
        *pnFrameRateExtD = 1001;
        return MFX_ERR_NONE;
    }

    *pnFrameRateExtN = (mfxU32)(dFrameRate * 10000 + .5);
    *pnFrameRateExtD = 10000;

    return MFX_ERR_NONE;    
}

mfxF64 CalculateFrameRate(mfxU32 nFrameRateExtN, mfxU32 nFrameRateExtD)
{
    if (nFrameRateExtN && nFrameRateExtD)
        return (mfxF64)nFrameRateExtN / nFrameRateExtD;
    else
        return 0;
}

mfxU16 GetFreeSurfaceIndex(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize)
{    
    if (pSurfacesPool)
    {
        for (mfxU16 i = 0; i < nPoolSize; i++)
        {
            if (0 == pSurfacesPool[i].Data.Locked)
            {       
                return i;
            }
        }
    }   

    return INVALID_SURF_IDX;
}

mfxU16 GetFreeSurface(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize)
{
    mfxU32 SleepInterval = 10; // milliseconds    

    mfxU16 idx = INVALID_SURF_IDX;

    //wait if there's no free surface
    for (mfxU32 i = 0; i < WAIT_INTERVAL; i += SleepInterval)
    {
        idx = GetFreeSurfaceIndex(pSurfacesPool, nPoolSize);

        if (INVALID_SURF_IDX != idx)
        {
            break;
        }
        else 
        {
            Sleep(SleepInterval);
        }        
    }          

    return idx;
}

mfxU16 GetFreeSurfaceIndex(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize, mfxU16 step)
{    
    if (pSurfacesPool)
    {
        for (mfxU16 i = 0; i < nPoolSize; i = (mfxU16)(i + step), pSurfacesPool += step)
        {
            if (0 == pSurfacesPool[0].Data.Locked)
            {       
                return i;
            }
        }
    }   

    return INVALID_SURF_IDX;
}

mfxStatus InitMfxBitstream(mfxBitstream* pBitstream, mfxU32 nSize)
{
    //check input params
    CHECK_POINTER(pBitstream, MFX_ERR_NULL_PTR);
    CHECK_ERROR(nSize, 0, MFX_ERR_NOT_INITIALIZED);

    //prepare pBitstream  
    WipeMfxBitstream(pBitstream);

    //prepare buffer
    pBitstream->Data = new mfxU8[nSize];
    CHECK_POINTER(pBitstream->Data, MFX_ERR_MEMORY_ALLOC);

    pBitstream->MaxLength = nSize;

    return MFX_ERR_NONE;
}

mfxStatus ExtendMfxBitstream(mfxBitstream* pBitstream, mfxU32 nSize)
{
    CHECK_POINTER(pBitstream, MFX_ERR_NULL_PTR);

    CHECK_ERROR(nSize <= pBitstream->MaxLength, true, MFX_ERR_UNSUPPORTED);
   
    mfxU8* pData = new mfxU8[nSize];  
    CHECK_POINTER(pData, MFX_ERR_MEMORY_ALLOC);

    memmove(pData, pBitstream->Data + pBitstream->DataOffset, pBitstream->DataLength);

    WipeMfxBitstream(pBitstream);

    pBitstream->Data       = pData;
    pBitstream->DataOffset = 0;
    pBitstream->MaxLength  = nSize;

    return MFX_ERR_NONE;
}

void WipeMfxBitstream(mfxBitstream* pBitstream)
{
    CHECK_POINTER_NO_RET(pBitstream);

    //free allocated memory
    SAFE_DELETE_ARRAY(pBitstream->Data);    
}

TCHAR* CodecIdToStr(mfxU32 nFourCC)
{
    switch(nFourCC)
    {
    case MFX_CODEC_AVC:
        return _T("AVC");
    case MFX_CODEC_VC1:
        return _T("VC1");
    case MFX_CODEC_MPEG2:
        return _T("MPEG2");
    default:
        return _T("NOT_SUPPORTED");
    }
}

PartiallyLinearFNC::PartiallyLinearFNC()
: m_pX()
, m_pY()
, m_nPoints()
, m_nAllocated()
{
}

PartiallyLinearFNC::~PartiallyLinearFNC()
{
    delete []m_pX;
    m_pX = NULL;
    delete []m_pY;
    m_pY = NULL;
}

void PartiallyLinearFNC::AddPair(mfxF64 x, mfxF64 y)
{
    //duplicates searching 
    for (mfxU32 i = 0; i < m_nPoints; i++)
    {
        if (m_pX[i] == x)
            return;
    }
    if (m_nPoints == m_nAllocated)
    {
        m_nAllocated += 20;
        mfxF64 * pnew;
        pnew = new mfxF64[m_nAllocated];
        memcpy(pnew, m_pX, sizeof(mfxF64) * m_nPoints);
        delete [] m_pX;
        m_pX = pnew;

        pnew = new mfxF64[m_nAllocated];
        memcpy(pnew, m_pY, sizeof(mfxF64) * m_nPoints);
        delete [] m_pY;
        m_pY = pnew;
    }
    m_pX[m_nPoints] = x;
    m_pY[m_nPoints] = y;

    m_nPoints ++;
}

mfxF64 PartiallyLinearFNC::at(mfxF64 x)
{
    if (m_nPoints < 2)
    {
        return 0;
    }
    bool bwasmin = false;
    bool bwasmax = false;

    mfxU32 maxx = 0;
    mfxU32 minx = 0;
    mfxU32 i;

    for (i=0; i < m_nPoints; i++)
    {
        if (m_pX[i] <= x && (!bwasmin || m_pX[i] > m_pX[maxx]))
        {
            maxx = i;
            bwasmin = true;
        }
        if (m_pX[i] > x && (!bwasmax || m_pX[i] < m_pX[minx]))
        {
            minx = i;
            bwasmax = true;
        }
    }

    //point on the left
    if (!bwasmin)
    {
        for (i=0; i < m_nPoints; i++)
        {
            if (m_pX[i] > m_pX[minx] && (!bwasmin || m_pX[i] < m_pX[minx]))
            {
                maxx = i;
                bwasmin = true;
            }
        }
    }
    //point on the right
    if (!bwasmax)
    {
        for (i=0; i < m_nPoints; i++)
        {
            if (m_pX[i] < m_pX[maxx] && (!bwasmax || m_pX[i] > m_pX[minx]))
            {
                minx = i;
                bwasmax = true;
            }
        }
    }

    //linear interpolation
    return (x - m_pX[minx])*(m_pY[maxx] - m_pY[minx]) / (m_pX[maxx] - m_pX[minx]) + m_pY[minx];
}

mfxU16 CalculateDefaultBitrate(mfxU32 nCodecId, mfxU32 nTargetUsage, mfxU32 nWidth, mfxU32 nHeight, mfxF64 dFrameRate)
{    
    PartiallyLinearFNC fnc;
    mfxF64 bitrate = 0;

    switch (nCodecId)
    {
    case MFX_CODEC_AVC : 
        {
            fnc.AddPair(0, 0);
            fnc.AddPair(25344, 225);
            fnc.AddPair(101376, 1000);
            fnc.AddPair(414720, 4000);
            fnc.AddPair(2058240, 5000);            
            break;
        }
    case MFX_CODEC_MPEG2: 
        {
            fnc.AddPair(0, 0);
            fnc.AddPair(414720, 12000);            
            break;        
        }        
    }   

    mfxF64 at = nWidth * nHeight * dFrameRate / 30.0;    

    switch (nTargetUsage)
    {
    case MFX_TARGETUSAGE_BEST_QUALITY :
        {
            bitrate = (&fnc)->at(at);
            break;
        }
    case MFX_TARGETUSAGE_BEST_SPEED :
        {
            bitrate = (&fnc)->at(at) * 0.5;
            break;
        }
    case MFX_TARGETUSAGE_BALANCED :
        {
            bitrate = (&fnc)->at(at) * 0.75;
            break;
        }        
    }    

    return (mfxU16)bitrate;
}

mfxU16 StrToTargetUsage(TCHAR* strInput)
{
    mfxU16 tu = MFX_TARGETUSAGE_BALANCED;

    if (0 == _tcscmp(strInput, _T("quality"))) 
    {
        tu = MFX_TARGETUSAGE_BEST_QUALITY;
    } 
    else if (0 == _tcscmp(strInput, _T("speed"))) 
    {
        tu = MFX_TARGETUSAGE_BEST_SPEED;
    }     

    return tu;
}

TCHAR* TargetUsageToStr(mfxU16 tu)
{
    switch(tu)
    {
    case MFX_TARGETUSAGE_BALANCED:
        return _T("balanced");
    case MFX_TARGETUSAGE_BEST_QUALITY:
        return _T("quality");
    case MFX_TARGETUSAGE_BEST_SPEED:
        return _T("speed");
    case MFX_TARGETUSAGE_UNKNOWN:
        return _T("unknown");
    default:
        return _T("unsupported");
    }
}

TCHAR* ColorFormatToStr(mfxU32 format)
{
    switch(format)
    {
    case MFX_FOURCC_NV12:
        return _T("NV12");
    case MFX_FOURCC_YV12:
        return _T("YUV420");    
    default:
        return _T("unsupported");
    }
}

mfxU32 GCD(mfxU32 a, mfxU32 b)
{    
    if (0 == a)
        return b;
    else if (0 == b)
        return a;

    mfxU32 a1, b1;

    if (a >= b)
    {
        a1 = a;
        b1 = b;
    }
    else 
    {
        a1 = b;
        b1 = a;
    }

    // a1 >= b1;
    mfxU32 r = a1 % b1;

    while (0 != r)
    {
        a1 = b1;
        b1 = r;
        r = a1 % b1;
    }

    return b1;
}

mfxStatus DARtoPAR(mfxU32 darw, mfxU32 darh, mfxU32 w, mfxU32 h, mfxU16 *pparw, mfxU16 *pparh)
{
    CHECK_POINTER(pparw, MFX_ERR_NULL_PTR);
    CHECK_POINTER(pparh, MFX_ERR_NULL_PTR);    
    CHECK_ERROR(darw, 0, MFX_ERR_UNDEFINED_BEHAVIOR);
    CHECK_ERROR(darh, 0, MFX_ERR_UNDEFINED_BEHAVIOR);
    CHECK_ERROR(w, 0, MFX_ERR_UNDEFINED_BEHAVIOR);
    CHECK_ERROR(h, 0, MFX_ERR_UNDEFINED_BEHAVIOR);

    mfxU16 reduced_w = 0, reduced_h = 0;
    mfxU32 gcd = GCD(w, h);

    // divide by greatest common divisor to fit into mfxU16
    reduced_w =  (mfxU16) (w / gcd);
    reduced_h =  (mfxU16) (h / gcd);

    // for mpeg2 we need to set exact values for par (standard supports only dar 4:3, 16:9, 221:100, 1:1)
    if (darw * 3 == darh * 4)
    {
        *pparw = 4 * reduced_h;
        *pparh = 3 * reduced_w;
    }
    else if (darw * 9 == darh * 16)
    {
        *pparw = 16 * reduced_h;
        *pparh = 9 * reduced_w;
    }
    else if (darw * 100 == darh * 221)
    {
        *pparw = 221 * reduced_h;
        *pparh = 100 * reduced_w;
    }
    else if (darw == darh)
    {
        *pparw = reduced_h;
        *pparh = reduced_w;
    }
    else
    {
        *pparw = (mfxU16)((DOUBLE)(darw * reduced_h) / (darh * reduced_w) * 1000);
        *pparh = 1000;
    }

    return MFX_ERR_NONE;
}

