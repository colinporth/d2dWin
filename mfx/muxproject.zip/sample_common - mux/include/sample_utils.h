/* ////////////////////////////////////////////////////////////////////////////// */
/*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
*/

#ifndef __SAMPLE_UTILS_H__
#define __SAMPLE_UTILS_H__

#include <tchar.h>
#include <stdio.h>

#include "mfxstructures.h"

#include "umc_structures.h"
#include "umc_muxer.h"
#include "umc_mp4_mux.h"
#include "umc_file_writer.h"
#include "umc_mpeg2_muxer.h"
#include "umc_mpeg2_muxer_chunk.h"

// A macro to disallow the copy constructor and operator= functions
// This should be used in the private: declarations for a class
#define DISALLOW_COPY_AND_ASSIGN(TypeName) \
    TypeName(const TypeName&);               \
    void operator=(const TypeName&)   

class CSmplYUVReader
{
public :

    CSmplYUVReader();
    virtual ~CSmplYUVReader();

    virtual mfxStatus Init(const TCHAR *strFileName, mfxU32 ColorFormat);
    virtual mfxStatus LoadNextFrame(mfxFrameSurface1* pSurface);
    virtual void Close();
    mfxU32 m_ColorFormat; // color format of input YUV data, YUV420 or NV12

protected:
    FILE* m_fSource;
    bool m_bInited;    
};

class CSmplBitstreamWriter
{
public :

    CSmplBitstreamWriter();
    virtual ~CSmplBitstreamWriter();

    virtual mfxStatus Init(const TCHAR *strFileName);
    virtual mfxStatus WriteNextFrame(mfxBitstream *pMfxBitstream, bool isPrint = true);
    virtual void Close();
    mfxU32 m_nProcessedFramesNum;
    
protected:
    FILE*       m_fSource;
    bool        m_bInited;    
};

class MuxWriter : public CSmplBitstreamWriter
{
public :
    MuxWriter();
    virtual ~MuxWriter();

    virtual mfxStatus Init( const TCHAR *strFileName,
							const mfxU16 nWidth,
							const mfxU16 nHeight,
							const mfxF64 dFrameRate,
							const mfxU16 nBitRate,
							const mfxU32 nCodecId);
    virtual mfxStatus WriteNextFrame(mfxBitstream *pMfxBitstream, bool isPrint = true);
    virtual void Close();

private:
	UMC::Muxer				*m_pMuxer;
	UMC::MuxerParams		*m_pMuxerParams;
	UMC::FileWriter			m_writer;
	UMC::FileWriterParams	m_fwp;
	UMC::VideoStreamInfo	m_videoInfo;
	UMC::MediaData			m_videoData;
	Ipp32s					m_videoTrackID;
	Ipp64f					m_frameDuration;
};


class CSmplYUVWriter
{
public :

    CSmplYUVWriter();
    virtual ~CSmplYUVWriter();

    virtual void      Close();
    virtual mfxStatus Init(const TCHAR *strFileName);
    virtual mfxStatus WriteNextFrame(mfxFrameSurface1 *pSurface);

protected:
    FILE*        m_fDest;
    bool         m_bInited;
};


class CSmplBitstreamReader
{
public :

    CSmplBitstreamReader();
    virtual ~CSmplBitstreamReader();

    virtual void      Close();
    virtual mfxStatus Init(const TCHAR *strFileName);
    virtual mfxStatus ReadNextFrame(mfxBitstream *pBS);

protected:
    FILE*     m_fSource;
    bool      m_bInited;
};

mfxStatus ConvertFrameRate(mfxF64 dFrameRate, mfxU32* pnFrameRateExtN, mfxU32* pnFrameRateExtD);
mfxF64 CalculateFrameRate(mfxU32 nFrameRateExtN, mfxU32 nFrameRateExtD);
mfxU16 GetFreeSurfaceIndex(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize);
mfxU16 GetFreeSurfaceIndex(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize, mfxU16 step);
mfxU16 GetFreeSurface(mfxFrameSurface1* pSurfacesPool, mfxU16 nPoolSize);
mfxStatus InitMfxBitstream(mfxBitstream* pBitstream, mfxU32 nSize);
mfxStatus ExtendMfxBitstream(mfxBitstream* pBitstream, mfxU32 nSize);
void WipeMfxBitstream(mfxBitstream* pBitstream);
TCHAR* CodecIdToStr(mfxU32 nFourCC);
mfxU16 CalculateDefaultBitrate(mfxU32 nCodecId, mfxU32 nTargetUsage, mfxU32 nWidth, mfxU32 nHeight, mfxF64 dFrameRate);
mfxU16 StrToTargetUsage(TCHAR* strInput);
TCHAR* TargetUsageToStr(mfxU16 tu);
TCHAR* ColorFormatToStr(mfxU32 format);

//piecewise linear function for bitrate approximation
class PartiallyLinearFNC
{
    mfxF64 *m_pX;
    mfxF64 *m_pY;
    mfxU32  m_nPoints;
    mfxU32  m_nAllocated;

public:
    PartiallyLinearFNC();
    ~PartiallyLinearFNC();

    void AddPair(mfxF64 x, mfxF64 y);
    mfxF64 at(mfxF64);
private:
    DISALLOW_COPY_AND_ASSIGN(PartiallyLinearFNC);
};

// function for conversion of display aspect ratio to pixel aspect ratio
mfxStatus DARtoPAR(mfxU32 darw, mfxU32 darh, mfxU32 w, mfxU32 h, mfxU16 *pparw, mfxU16 *pparh);

#endif //__SAMPLE_UTILS_H__