/* ////////////////////////////////////////////////////////////////////////////// */
/*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
*/

#ifndef __SAMPLE_DEFS_H__
#define __SAMPLE_DEFS_H__

#include <tchar.h>
#include <memory.h>

#include "mfxdefs.h"

#define DEC_WAIT_INTERVAL 60000
#define ENC_WAIT_INTERVAL 10000
#define VPP_WAIT_INTERVAL 60000
#define WAIT_INTERVAL 3 * VPP_WAIT_INTERVAL + ENC_WAIT_INTERVAL // an estimate for the longest pipeline

#define INVALID_SURF_IDX 0xFFFF

#define MAX_FILENAME_LEN 1024

#define PRINT_RET_MSG _tprintf(_T("\n\nReturn on error: %s\t%d\n"), _T(__FILE__), __LINE__)

#define CHECK_ERROR(P, X, ERR)              {if ((X) == (P)) {PRINT_RET_MSG; return ERR;}}
#define CHECK_NOT_EQUAL(P, X, ERR)          {if ((X) != (P)) {PRINT_RET_MSG; return ERR;}}
#define CHECK_RESULT(P, X, ERR)             {if ((X) > (P)) {PRINT_RET_MSG; return ERR;}}
#define CHECK_RESULT_SAFE(P, X, ERR, ADD)   {if ((X) > (P)) {ADD; PRINT_RET_MSG; return ERR;}}
#define IGNORE_MFX_STS(P, X)                {if ((X) == (P)) {P = MFX_ERR_NONE;}}
#define CHECK_POINTER(P, ERR)               {if (!(P)) {return ERR;}}
#define CHECK_POINTER_NO_RET(P)             {if (!(P)) {return;}}
#define CHECK_POINTER_SAFE(P, ERR, ADD)     {if (!(P)) {ADD; return ERR;}}
#define BREAK_ON_ERROR(P)                   {if (MFX_ERR_NONE != (P)) break;}
#define SAFE_DELETE_ARRAY(P)                {if (P) {delete[] P; P = NULL;}}
#define SAFE_RELEASE(X)                     {if (X) { X->Release(); X = NULL; }}

#ifndef SAFE_DELETE
#define SAFE_DELETE(P)                      {if (P) {delete P; P = NULL;}}
#endif // SAFE_DELETE

#define ZERO_MEMORY(VAR)                    {memset(&VAR, 0, sizeof(VAR));}
#define MAX(A, B)                           (((A) > (B)) ? (A) : (B))
#define MIN(A, B)                           (((A) < (B)) ? (A) : (B))
#define ALIGN16(SZ)                         (((SZ + 15) >> 4) << 4) // round up to a multiple of 16
#define ALIGN32(SZ)                         (((SZ + 31) >> 5) << 5) // round up to a multiple of 32

#endif //__SAMPLE_DEFS_H__