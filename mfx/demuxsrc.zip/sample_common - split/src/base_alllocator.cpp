/* ****************************************************************************** *\

INTEL CORPORATION PROPRIETARY INFORMATION
This software is supplied under the terms of a license agreement or nondisclosure
agreement with Intel Corporation and may not be copied or disclosed except in
accordance with the terms of that agreement
Copyright(c) 2008-2010 Intel Corporation. All Rights Reserved.

\* ****************************************************************************** */

#include <assert.h>
#include "base_allocator.h"

MFXFrameAllocator::MFXFrameAllocator()
{    
    pthis = this;
    Alloc = Alloc_;
    Lock  = Lock_;
    Free  = Free_;
    Unlock = Unlock_;
    GetHDL = GetHDL_;
}

MFXFrameAllocator::~MFXFrameAllocator()
{
}

mfxStatus MFXFrameAllocator::Alloc_(mfxHDL pthis, mfxFrameAllocRequest *request, mfxFrameAllocResponse *response)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXFrameAllocator& self = *(MFXFrameAllocator *)pthis;

    return self.AllocFrames(request, response);
}

mfxStatus MFXFrameAllocator::Lock_(mfxHDL pthis, mfxMemId mid, mfxFrameData *ptr)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXFrameAllocator& self = *(MFXFrameAllocator *)pthis;

    return self.LockFrame(mid, ptr);
}

mfxStatus MFXFrameAllocator::Unlock_(mfxHDL pthis, mfxMemId mid, mfxFrameData *ptr)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXFrameAllocator& self = *(MFXFrameAllocator *)pthis;

    return self.UnlockFrame(mid, ptr);
}

mfxStatus MFXFrameAllocator::Free_(mfxHDL pthis, mfxFrameAllocResponse *response)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXFrameAllocator& self = *(MFXFrameAllocator *)pthis;

    return self.FreeFrames(response);
}

mfxStatus MFXFrameAllocator::GetHDL_(mfxHDL pthis, mfxMemId mid, mfxHDL *handle)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXFrameAllocator& self = *(MFXFrameAllocator *)pthis;

    return self.GetFrameHDL(mid, handle);
}

BaseFrameAllocator::BaseFrameAllocator()
{
}

BaseFrameAllocator::~BaseFrameAllocator()
{
}

mfxStatus BaseFrameAllocator::CheckRequestType(mfxFrameAllocRequest *request)
{
    if (0 == request)
        return MFX_ERR_NULL_PTR;

    // check that Media SDK component is specified in request 
    if ((request->Type & MEMTYPE_FROM_MASK) != 0)
        return MFX_ERR_NONE;
    else
        return MFX_ERR_UNSUPPORTED;
}

mfxStatus BaseFrameAllocator::AllocFrames(mfxFrameAllocRequest *request, mfxFrameAllocResponse *response)
{
    if (0 == request || 0 == response || 0 == request->NumFrameSuggested)
        return MFX_ERR_MEMORY_ALLOC; 

    if (MFX_ERR_NONE != CheckRequestType(request))
        return MFX_ERR_UNSUPPORTED;

    mfxStatus sts = MFX_ERR_NONE;

    if (request->Type & MFX_MEMTYPE_EXTERNAL_FRAME)
    {
        // external allocations

        // check if suitable response for this component exists, 
        // means that external surfaces for this component have been allocated already
        mfxU32 resp = 0;
        for (; resp < MAX_NUM_EXTERNAL_CHAIN; resp++)
            if ((m_externals[resp].m_type & request->Type) != 0)
                break;
       
        if (resp < MAX_NUM_EXTERNAL_CHAIN)
        {            
            // check if enough frames were allocated
            if (request->NumFrameMin > m_externals[resp].m_response.NumFrameActual)
                return MFX_ERR_MEMORY_ALLOC;

            m_externals[resp].m_refCount++;
            // return existing response
            *response = m_externals[resp].m_response;
        }
        else 
        {
            // allocate memory
            // find unused response
            // there always should be unused one
            mfxU32 resp = 0;
            for (; resp < MAX_NUM_EXTERNAL_CHAIN; resp++)
                if (m_externals[resp].m_refCount == 0)
                    break;

            if (resp == MAX_NUM_EXTERNAL_CHAIN)
            {
                assert(!"logic error: no free response for externals");
                return MFX_ERR_MEMORY_ALLOC;
            }

            sts = AllocImpl(request, response);
            if (sts == MFX_ERR_NONE)
            {
                m_externals[resp].m_response = *response;
                m_externals[resp].m_refCount = 1;
                m_externals[resp].m_type = request->Type & MEMTYPE_FROM_MASK;
            }           
        }
    }
    else
    {
        // internal allocations

        // reserve space before allocation to avoid memory leak
        m_internals.push_back(mfxFrameAllocResponse());

        sts = AllocImpl(request, response);
        if (sts == MFX_ERR_NONE)
        {
            m_internals.back() = *response;           
        }
        else
        {
            m_internals.pop_back();
        }     
    }

    return sts;
}

bool BaseFrameAllocator::IsSame(const mfxFrameAllocResponse& l, const mfxFrameAllocResponse& r)
{
    return l.mids != 0 && r.mids != 0 && l.mids[0] == r.mids[0] && l.NumFrameActual == r.NumFrameActual;
}

mfxStatus BaseFrameAllocator::FreeFrames(mfxFrameAllocResponse *response)
{
    if (response == 0)
        return MFX_ERR_INVALID_HANDLE;

    mfxStatus sts = MFX_ERR_NONE;
    
    // first of all search freeing response in responses for external frames
    for (mfxU32 i = 0; i < MAX_NUM_EXTERNAL_CHAIN; i++)
    {
        if (m_externals[i].m_refCount > 0 && IsSame(*response, m_externals[i].m_response))
        {
            if (--m_externals[i].m_refCount == 0)
            {
                sts = ReleaseResponse(response);
                m_externals[i].Reset();
            }
            return sts;
        }
    }

    // if not found so far, then search in internal responses
    for (Iter i = m_internals.begin(); i != m_internals.end(); ++i)
    {
        if (IsSame(*response, *i))
        {
            sts = ReleaseResponse(response);
            m_internals.erase(i);
            return sts;
        }
    }

    // not found anywhere, report an error
    return MFX_ERR_INVALID_HANDLE;
}

mfxStatus BaseFrameAllocator::Close()
{
    for (mfxU32 i = 0; i < MAX_NUM_EXTERNAL_CHAIN; i++)
    {
        ReleaseResponse(&(m_externals[i].m_response));
        m_externals[i].Reset();
    }
    
    while (!m_internals.empty())
    {        
        ReleaseResponse(&(*m_internals.begin()));
        m_internals.pop_front();
    }
    
    return MFX_ERR_NONE;
}

MFXBufferAllocator::MFXBufferAllocator()
{    
    pthis = this;
    Alloc = Alloc_;
    Lock  = Lock_;
    Free  = Free_;
    Unlock = Unlock_;
}

MFXBufferAllocator::~MFXBufferAllocator()
{
}

mfxStatus MFXBufferAllocator::Alloc_(mfxHDL pthis, mfxU32 nbytes, mfxU16 type, mfxMemId *mid)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXBufferAllocator& self = *(MFXBufferAllocator *)pthis;

    return self.AllocBuffer(nbytes, type, mid);
}

mfxStatus MFXBufferAllocator::Lock_(mfxHDL pthis, mfxMemId mid, mfxU8 **ptr)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXBufferAllocator& self = *(MFXBufferAllocator *)pthis;

    return self.LockBuffer(mid, ptr);
}

mfxStatus MFXBufferAllocator::Unlock_(mfxHDL pthis, mfxMemId mid)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXBufferAllocator& self = *(MFXBufferAllocator *)pthis;

    return self.UnlockBuffer(mid);
}

mfxStatus MFXBufferAllocator::Free_(mfxHDL pthis, mfxMemId mid)
{
    if (0 == pthis)
        return MFX_ERR_MEMORY_ALLOC;

    MFXBufferAllocator& self = *(MFXBufferAllocator *)pthis;

    return self.FreeBuffer(mid);
}

