//
//               INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in accordance with the terms of that agreement.
//        Copyright (c) 2005-2009 Intel Corporation. All Rights Reserved.
//
#include "pipeline_decode.h"

void PrintHelp(TCHAR *strAppName, TCHAR *strErrorMessage)
{
    if (strErrorMessage)
    {
        _tprintf(_T("Error: %s\n"), strErrorMessage);
    } 
    else
    {
        _tprintf(_T("Intel(R) Media SDK Decoding Sample \n"));
    }
    _tprintf(_T("Usage: %s mpeg2|h264|vc1 -i InputBitstream -o OutputYUVFile\n"), strAppName);
    _tprintf(_T("Options: \n"));
    _tprintf(_T("   [-hw]          - use platform specific SDK implementation, if not specified software implementation is used\n"));
#ifdef D3D_SURFACES_SUPPORT    
    _tprintf(_T("   [-d3d]         - work with d3d surfaces\n"));
#endif
	_tprintf(_T("   [-split]       - Extract video stream from container\n"));
    _tprintf(_T("\n"));
}

#define GET_OPTION_POINTER(PTR)        \
{                                      \
    if (2 == _tcslen(strInput[i]))     \
    {                                  \
        i++;                           \
        if (strInput[i][0] == _T('-')) \
        {                              \
            i = i - 1;                 \
        }                              \
        else                           \
        {                              \
            PTR = strInput[i];         \
        }                              \
    }                                  \
    else                               \
    {                                  \
        PTR = strInput[i] + 2;         \
    }                                  \
}

mfxStatus ParseInputString(TCHAR* strInput[], mfxU8 nArgNum, sInputParams* pParams)
{   
    TCHAR* strArgument = _T("");

    if (1 == nArgNum)
    {
        PrintHelp(strInput[0], NULL);
        return MFX_ERR_UNSUPPORTED;
    }

    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);
    ZERO_MEMORY(*pParams);

    for (mfxU8 i = 1; i < nArgNum; i++)
    {
        if (_T('-') != strInput[i][0])
        {
            if (0 == _tcscmp(strInput[i], _T("mpeg2")))
            {
                pParams->videoType = MFX_CODEC_MPEG2;
            }
            else if (0 == _tcscmp(strInput[i], _T("h264")))
            {
                pParams->videoType = MFX_CODEC_AVC;
            }
            else if (0 == _tcscmp(strInput[i], _T("vc1")))
            {
                pParams->videoType = MFX_CODEC_VC1;
            }
            else
            {
                PrintHelp(strInput[0], _T("Unknown codec"));
                return MFX_ERR_UNSUPPORTED;
            }
            continue;
        }

        // multi-character options
        if (0 == _tcscmp(strInput[i], _T("-hw")))
        {
            pParams->bUseHWLib = true;
        }
#ifdef D3D_SURFACES_SUPPORT
        else if (0 == _tcscmp(strInput[i], _T("-d3d")))
        {
            pParams->bd3dAlloc = true;
        }
#endif    
		else if (0 == _tcscmp(strInput[i], _T("-split")))
        {
            pParams->bSplit = true;
        }
        else // 1-character options
        {
            switch (strInput[i][1])
            {
            case _T('i'):
                GET_OPTION_POINTER(strArgument);
                _tcscpy_s(pParams->strSrcFile, strArgument);
                break;
            case _T('o'):
                GET_OPTION_POINTER(strArgument);
                _tcscpy_s(pParams->strDstFile, strArgument);
                break;            
            case _T('?'):
                PrintHelp(strInput[0], NULL);
                return MFX_ERR_UNSUPPORTED;
            default:
                PrintHelp(strInput[0], _T("Unknown options"));
            }
        }
    }

    if (0 == _tcslen(pParams->strSrcFile))
    {
        PrintHelp(strInput[0], _T("Source file name not found"));
        return MFX_ERR_UNSUPPORTED;
    }

    if (0 == _tcslen(pParams->strDstFile))
    {
        PrintHelp(strInput[0], _T("Destination file name not found"));
        return MFX_ERR_UNSUPPORTED;
    }

    if (MFX_CODEC_MPEG2!= pParams->videoType && MFX_CODEC_AVC != pParams->videoType && MFX_CODEC_VC1!= pParams->videoType)
    {
        PrintHelp(strInput[0], _T("Unknown codec"));
        return MFX_ERR_UNSUPPORTED;
    }

    return MFX_ERR_NONE;
}

int _tmain(int argc, TCHAR *argv[])
{
    sInputParams        Params;   // input parameters from command line
    CDecodingPipeline   Pipeline; // pipeline for decoding, includes input file reader, decoder and output file writer

    mfxStatus sts = MFX_ERR_NONE; // return value check

    sts = ParseInputString(argv, (mfxU8)argc, &Params);
    CHECK_RESULT(sts, MFX_ERR_NONE, 1);

    sts = Pipeline.Init(&Params);
    CHECK_RESULT(sts, MFX_ERR_NONE, 1);   

    _tprintf(_T("Decoding started\n"));

    for (;;)
    {
        sts = Pipeline.RunDecoding();

        if (MFX_ERR_INCOMPATIBLE_VIDEO_PARAM == sts || MFX_ERR_DEVICE_LOST == sts || MFX_ERR_DEVICE_FAILED == sts)
        {
            if (MFX_ERR_INCOMPATIBLE_VIDEO_PARAM == sts)
            {
                _tprintf(_T("\nERROR: Incompatible video parameters detected. Recovering...\n"));
            }
            else
            {
                _tprintf(_T("\nERROR: Hardware device was lost or returned unexpected error. Recovering...\n"));
                sts = Pipeline.ResetDevice();
                CHECK_RESULT(sts, MFX_ERR_NONE, 1);
            }           

            sts = Pipeline.ResetDecoder();
            CHECK_RESULT(sts, MFX_ERR_NONE, 1);            
            continue;
        }        
        else
        {
            CHECK_RESULT(sts, MFX_ERR_NONE, 1);
            break;
        }
    }
    
    _tprintf(_T("\nDecoding finished\n"));

    Pipeline.Close();

    return 0;
}
