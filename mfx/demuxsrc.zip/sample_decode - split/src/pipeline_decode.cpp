//
//               INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in accordance with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//

#include <windows.h>

#include "pipeline_decode.h"
#include "sysmem_allocator.h"

#ifdef D3D_SURFACES_SUPPORT
#include "d3d_allocator.h"
#endif

mfxStatus CDecodingPipeline::InitMfxParams()
{
    CHECK_POINTER(m_pmfxDEC, MFX_ERR_NULL_PTR);

    mfxStatus sts = MFX_ERR_NONE;

    // try to find a sequence header in the stream
    // if header is not found this function exits with error (e.g. if device was lost and there's no header in the remaining stream)
    for(;;)
    {     
        // parse bit stream and fill mfx params
        sts = m_pmfxDEC->DecodeHeader(&m_mfxBS, &m_mfxVideoParams);

        if (MFX_ERR_MORE_DATA == sts)
        {
            if (m_mfxBS.MaxLength == m_mfxBS.DataLength)
            {
                sts = ExtendMfxBitstream(&m_mfxBS, m_mfxBS.MaxLength * 2); 
                CHECK_RESULT(sts, MFX_ERR_NONE, sts);
            }
            // read a portion of data             
            sts = m_pFileReader->ReadNextFrame(&m_mfxBS);
            CHECK_RESULT(sts, MFX_ERR_NONE, sts);

            continue;
        }
        else 
            break;
    }

    // check DecodeHeader status
    IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);        
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    
    // specify memory type 
    m_mfxVideoParams.IOPattern = (mfxU16)(m_bd3dAlloc ? MFX_IOPATTERN_OUT_VIDEO_MEMORY : MFX_IOPATTERN_OUT_SYSTEM_MEMORY);

    m_mfxVideoParams.mfx.DecodedOrder = 0; // binary flag, 0 signals decoder to output frames in display order

    return MFX_ERR_NONE;
}

mfxStatus CDecodingPipeline::CreateDeviceManager()
{  
#ifdef D3D_SURFACES_SUPPORT
    m_pd3d = Direct3DCreate9(D3D_SDK_VERSION);
    if (!m_pd3d)
        return MFX_ERR_NULL_PTR;

    POINT point = {0, 0};
    HWND window = WindowFromPoint(point);

    D3DPRESENT_PARAMETERS d3dParams;
    memset(&d3dParams, 0, sizeof(d3dParams));
    d3dParams.Windowed = TRUE;
    d3dParams.hDeviceWindow = window;
    d3dParams.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dParams.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
    d3dParams.Flags = D3DPRESENTFLAG_VIDEO;
    d3dParams.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
    d3dParams.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    d3dParams.BackBufferCount = 1;
    d3dParams.BackBufferFormat = D3DFMT_X8R8G8B8;
    d3dParams.BackBufferWidth = 0;
    d3dParams.BackBufferHeight = 0;
    
    HRESULT hr = m_pd3d->CreateDevice(
        D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        window,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING | D3DCREATE_MULTITHREADED | D3DCREATE_FPU_PRESERVE,
        &d3dParams,
        &m_pd3dDevice);
    if (FAILED(hr))
        return MFX_ERR_NULL_PTR;

    UINT resetToken = 0;    
    hr = DXVA2CreateDirect3DDeviceManager9(&resetToken, &m_pd3dDeviceManager);
    if (FAILED(hr))
        return MFX_ERR_NULL_PTR;

    hr = m_pd3dDeviceManager->ResetDevice(m_pd3dDevice, resetToken);
    if (FAILED(hr))
        return MFX_ERR_UNDEFINED_BEHAVIOR;
    
    m_resetToken = resetToken;

 #endif
    return MFX_ERR_NONE;
}

mfxStatus CDecodingPipeline::ResetDevice()
{
#ifdef D3D_SURFACES_SUPPORT
    if (m_bd3dAlloc)
    {
        HRESULT hr = m_pd3dDeviceManager->ResetDevice(m_pd3dDevice, m_resetToken);
        if (FAILED(hr))
        {
            return MFX_ERR_UNDEFINED_BEHAVIOR;
        }
    }    
#endif
    return MFX_ERR_NONE;    
}

mfxStatus CDecodingPipeline::AllocFrames()
{
    CHECK_POINTER(m_pmfxDEC, MFX_ERR_NULL_PTR);

    mfxStatus sts = MFX_ERR_NONE;

    mfxFrameAllocRequest Request;

    mfxU16 nSurfNum = 0; // number of surfaces for decoder

    ZERO_MEMORY(Request);

    // calculate number of surfaces required for decoder
    sts = m_pmfxDEC->QueryIOSurf(&m_mfxVideoParams, &Request);
    IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    nSurfNum = MAX(Request.NumFrameSuggested, 1);

    // prepare allocation request
    Request.NumFrameMin = nSurfNum;
    Request.NumFrameSuggested = nSurfNum;
    memcpy(&(Request.Info), &(m_mfxVideoParams.mfx.FrameInfo), sizeof(mfxFrameInfo));
    Request.Type = MFX_MEMTYPE_EXTERNAL_FRAME | MFX_MEMTYPE_FROM_DECODE; 

    // add info about memory type to request 
    Request.Type |= m_bd3dAlloc ? MFX_MEMTYPE_DXVA2_DECODER_TARGET : MFX_MEMTYPE_SYSTEM_MEMORY; 
    // alloc frames for decoder
    sts = m_pMFXAllocator->Alloc(m_pMFXAllocator->pthis, &Request, &m_mfxResponse);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // prepare mfxFrameSurface1 array for decoder
    nSurfNum = m_mfxResponse.NumFrameActual;
    m_pmfxSurfaces = new mfxFrameSurface1 [nSurfNum];    

    for (int i = 0; i < nSurfNum; i++)
    {       
        memset(&(m_pmfxSurfaces[i]), 0, sizeof(mfxFrameSurface1));
        memcpy(&(m_pmfxSurfaces[i].Info), &(m_mfxVideoParams.mfx.FrameInfo), sizeof(mfxFrameInfo));

        if (m_bExternalAlloc)
        {
            m_pmfxSurfaces[i].Data.MemId = m_mfxResponse.mids[i];    
        }
        else
        {
            sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, m_mfxResponse.mids[i], &(m_pmfxSurfaces[i].Data));
            CHECK_RESULT(sts, MFX_ERR_NONE, sts);
        }
    }  

    return MFX_ERR_NONE;
}

mfxStatus CDecodingPipeline::CreateAllocator()
{   
    mfxStatus sts = MFX_ERR_NONE;
 
    if (m_bd3dAlloc)
    {
#ifdef D3D_SURFACES_SUPPORT       
        sts = CreateDeviceManager();
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        // provide device manager to MediaSDK
        sts = m_mfxSession.SetHandle(MFX_HANDLE_DIRECT3D_DEVICE_MANAGER9, m_pd3dDeviceManager);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        // crate D3D allocator
        m_pMFXAllocator = new D3DFrameAllocator;        

        D3DAllocatorParams *pd3dAllocParams = new D3DAllocatorParams;        

        pd3dAllocParams->pManager = m_pd3dDeviceManager;
        m_pmfxAllocatorParams = pd3dAllocParams;

        /* In case of video memory we must provide MediaSDK with external allocator 
        thus we demonstrate "external allocator" usage model.
        Call SetAllocator to pass allocator to mediasdk */
        sts = m_mfxSession.SetFrameAllocator(m_pMFXAllocator);
        CHECK_RESULT(sts, MFX_ERR_NONE, sts);

        m_bExternalAlloc = true;  
#endif
    } 
    else
    {        
        // create system memory allocator       
        m_pMFXAllocator = new SysMemFrameAllocator;         

        /* In case of system memory we demonstrate "no external allocator" usage model.  
        We don't call SetAllocator, MediaSDK uses internal allocator. 
        We use system memory allocator simply as a memory manager for application*/           
    }   

    // initialize memory allocator
    sts = m_pMFXAllocator->Init(m_pmfxAllocatorParams);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
    
    return MFX_ERR_NONE;
}

void CDecodingPipeline::DeleteFrames()
{
    // delete surfaces array
    SAFE_DELETE_ARRAY(m_pmfxSurfaces);    

    // delete frames
    if (m_pMFXAllocator)
    {        
        m_pMFXAllocator->Free(m_pMFXAllocator->pthis, &m_mfxResponse);
    }

    return;
}

void CDecodingPipeline::DeleteAllocator()
{    
    // delete allocator
    SAFE_DELETE(m_pMFXAllocator);   
    SAFE_DELETE(m_pmfxAllocatorParams);

#ifdef D3D_SURFACES_SUPPORT     
    SAFE_RELEASE(m_pd3dDevice);
    SAFE_RELEASE(m_pd3dDeviceManager);
    SAFE_RELEASE(m_pd3d);  
#endif   
}

CDecodingPipeline::CDecodingPipeline()
{
    m_nFrameIndex = 0;
    m_pmfxDEC = NULL;
    m_pMFXAllocator = NULL;
    m_pmfxAllocatorParams = NULL;
    m_bd3dAlloc = false;
    m_bExternalAlloc = false;
    m_pmfxSurfaces = NULL;   

#ifdef D3D_SURFACES_SUPPORT
    m_pd3d = NULL;
    m_pd3dDeviceManager = NULL;  
    m_pd3dDevice        = NULL;
    m_resetToken        = 0;
#endif 

	m_pFileReader = NULL;

    ZERO_MEMORY(m_mfxVideoParams);
    ZERO_MEMORY(m_mfxResponse);
    ZERO_MEMORY(m_mfxBS);
}

CDecodingPipeline::~CDecodingPipeline()
{
    Close();

	SAFE_DELETE(m_pFileReader);
}

mfxStatus CDecodingPipeline::Init(sInputParams *pParams)
{
    CHECK_POINTER(pParams, MFX_ERR_NULL_PTR);

    mfxStatus sts = MFX_ERR_NONE;

    // prepare input stream file reader
	if(!pParams->bSplit)
	{
		m_pFileReader = new CSmplBitstreamReader();
		sts = m_pFileReader->Init(pParams->strSrcFile);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}
	else
	{
		m_pFileReader = new SplitterReader();
		sts = static_cast<SplitterReader*>(m_pFileReader)->Init(
					pParams->strSrcFile,
					pParams->videoType);
		CHECK_RESULT(sts, MFX_ERR_NONE, sts);
	}

    // prepare YUV file writer
    sts = m_FileWriter.Init(pParams->strDstFile);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);  
  
    // init session
    mfxIMPL impl = pParams->bUseHWLib ? MFX_IMPL_HARDWARE : MFX_IMPL_SOFTWARE;
    mfxVersion version = {0, 1};  // this sample requires 1.0 Media SDK API
    sts = m_mfxSession.Init(impl, &version);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // create decoder
    m_pmfxDEC = new MFXVideoDECODE(m_mfxSession);    

    // set video type in parameters
    m_mfxVideoParams.mfx.CodecId = pParams->videoType; 
    // set memory type
    m_bd3dAlloc = pParams->bd3dAlloc;

    // prepare bit stream
    sts = InitMfxBitstream(&m_mfxBS, 1024 * 1024);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);    

    sts = InitMfxParams();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);
  
    // init allocator 
    sts = CreateAllocator();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // if allocator is provided to MediaSDK as external, frames must be allocated prior to decoder initialization
    sts = AllocFrames();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // init decoder
    sts = m_pmfxDEC->Init(&m_mfxVideoParams);
    IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE;
}

void CDecodingPipeline::Close()
{
    WipeMfxBitstream(&m_mfxBS);
    SAFE_DELETE(m_pmfxDEC);   

    DeleteFrames();
    
    // allocator if used as external for MediaSDK must be deleted after decoder
    DeleteAllocator();

    m_mfxSession.Close();
    m_FileWriter.Close();

	if(m_pFileReader)
		m_pFileReader->Close();

    return;
}

mfxStatus CDecodingPipeline::ResetDecoder()
{
    mfxStatus sts = MFX_ERR_NONE;    

    // close decoder
    sts = m_pmfxDEC->Close();
    IGNORE_MFX_STS(sts, MFX_ERR_NOT_INITIALIZED);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // free allocated frames
    DeleteFrames();
    
    // initialize parameters with values from parsed header 
    sts = InitMfxParams();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // allocate frames prior to decoder initialization (if allocator used as external)
    sts = AllocFrames();
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // init decoder
    sts = m_pmfxDEC->Init(&m_mfxVideoParams);
    IGNORE_MFX_STS(sts, MFX_WRN_PARTIAL_ACCELERATION);
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    return MFX_ERR_NONE;
}

mfxStatus CDecodingPipeline::RunDecoding()
{   
    mfxSyncPoint        syncp;
    mfxFrameSurface1    *pmfxOutSurface = NULL;
    mfxStatus           sts = MFX_ERR_NONE;
    mfxU16              nIndex = 0; // index of free surface

    // print stream info 
    PrintInfo();    

    while (MFX_ERR_NONE <= sts || MFX_ERR_MORE_DATA == sts || MFX_ERR_MORE_SURFACE == sts)          
    {
        if (MFX_WRN_DEVICE_BUSY == sts)
        {
            Sleep(1); // just wait and then repeat the same call to DecodeFrameAsync
        }
        else if (MFX_ERR_MORE_DATA == sts)
        {
            sts = m_pFileReader->ReadNextFrame(&m_mfxBS); // read more data to input bit stream 
            BREAK_ON_ERROR(sts);            
        }
        else if (MFX_ERR_MORE_SURFACE == sts || MFX_ERR_NONE == sts)
        {
            nIndex = GetFreeSurfaceIndex(m_pmfxSurfaces, m_mfxResponse.NumFrameActual); // find new working surface 

            if (INVALID_SURF_IDX == nIndex)
            {
                return MFX_ERR_MEMORY_ALLOC;            
            }
        }
      
        sts = m_pmfxDEC->DecodeFrameAsync(&m_mfxBS, &(m_pmfxSurfaces[nIndex]), &pmfxOutSurface, &syncp); 

        // ignore warnings if output is available, 
        // if no output and no action required just repeat the same call
        if (MFX_ERR_NONE < sts && syncp) 
        {
            sts = MFX_ERR_NONE;
        }

        if (MFX_ERR_NONE == sts)
        {
            sts = m_mfxSession.SyncOperation(syncp, DEC_WAIT_INTERVAL);             
        }            

        if (MFX_ERR_NONE == sts)
        {                
            if (m_bExternalAlloc) 
            {
                sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, pmfxOutSurface->Data.MemId, &(pmfxOutSurface->Data));
                BREAK_ON_ERROR(sts);

                sts = m_FileWriter.WriteNextFrame(pmfxOutSurface);
                BREAK_ON_ERROR(sts);

                sts = m_pMFXAllocator->Unlock(m_pMFXAllocator->pthis, pmfxOutSurface->Data.MemId, &(pmfxOutSurface->Data));
                BREAK_ON_ERROR(sts);
            }
            else 
            {
                sts = m_FileWriter.WriteNextFrame(pmfxOutSurface);
                BREAK_ON_ERROR(sts);
            }            

            //decoding progress
            _tcprintf(_T("Frame number: %d\r"), ++m_nFrameIndex);            
        }

    } //while processing    

    //save the main loop exit status (required for the case of ERR_INCOMPATIBLE_PARAMS)
    mfxStatus mainloop_sts = sts; 

    // means that file has ended, need to go to buffering loop
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // incompatible video parameters detected, 
    //need to go to the buffering loop prior to reset procedure 
    IGNORE_MFX_STS(sts, MFX_ERR_INCOMPATIBLE_VIDEO_PARAM); 
    // exit in case of other errors

	printf("sts = %d\n", sts);

    CHECK_RESULT(sts, MFX_ERR_NONE, sts);          
      
    // loop to retrieve the buffered decoded frames
    while (MFX_ERR_NONE <= sts || MFX_ERR_MORE_SURFACE == sts)        
    {        
        if (MFX_WRN_DEVICE_BUSY == sts)
        {
            Sleep(5);
        }

        mfxU16 nIndex = GetFreeSurfaceIndex(m_pmfxSurfaces, m_mfxResponse.NumFrameActual);

        if (INVALID_SURF_IDX == nIndex)
        {
            return MFX_ERR_MEMORY_ALLOC;            
        }

        sts = m_pmfxDEC->DecodeFrameAsync(NULL, &(m_pmfxSurfaces[nIndex]), &pmfxOutSurface, &syncp);

        // ignore warnings if output is available, 
        // if no output and no action required just repeat the same call
        if (MFX_ERR_NONE < sts && syncp) 
        {
            sts = MFX_ERR_NONE;
        }

        if (MFX_ERR_NONE == sts)
        {
            sts = m_mfxSession.SyncOperation(syncp, DEC_WAIT_INTERVAL);
        }

        if (MFX_ERR_NONE == sts)
        {
            if (m_bExternalAlloc) 
            {
                sts = m_pMFXAllocator->Lock(m_pMFXAllocator->pthis, pmfxOutSurface->Data.MemId, &(pmfxOutSurface->Data));
                BREAK_ON_ERROR(sts);

                sts = m_FileWriter.WriteNextFrame(pmfxOutSurface);
                BREAK_ON_ERROR(sts);

                sts = m_pMFXAllocator->Unlock(m_pMFXAllocator->pthis, pmfxOutSurface->Data.MemId, &(pmfxOutSurface->Data));
                BREAK_ON_ERROR(sts);
            }
            else 
            {
                sts = m_FileWriter.WriteNextFrame(pmfxOutSurface);
                BREAK_ON_ERROR(sts);
            }            

            //decoding progress
            _tcprintf(_T("Frame number: %d\r"), ++m_nFrameIndex);          
        }
    } 

    // MFX_ERR_MORE_DATA is the correct status to exit buffering loop with
    IGNORE_MFX_STS(sts, MFX_ERR_MORE_DATA);
    // exit in case of other errors
    CHECK_RESULT(sts, MFX_ERR_NONE, sts);

    // if we exited main decoding loop with ERR_INCOMPATIBLE_PARAM we need to send this status to caller
    if (MFX_ERR_INCOMPATIBLE_VIDEO_PARAM == mainloop_sts) 
    {
        sts = mainloop_sts; 
    }

    return sts; // ERR_NONE or ERR_INCOMPATIBLE_VIDEO_PARAM
}

void CDecodingPipeline::PrintInfo()
{       
    _tprintf(_T("\nInput video\t%s\n"), CodecIdToStr(m_mfxVideoParams.mfx.CodecId));
    _tprintf(_T("Output format\t%s\n"), _T("YUV420"));

    mfxFrameInfo Info = m_mfxVideoParams.mfx.FrameInfo;
    _tprintf(_T("Resolution\t%dx%d\n"), Info.Width, Info.Height);
    _tprintf(_T("Crop X,Y,W,H\t%d,%d,%d,%d\n"), Info.CropX, Info.CropY, Info.CropW, Info.CropH);

    mfxF64 dFrameRate = CalculateFrameRate(Info.FrameRateExtN, Info.FrameRateExtD);
    _tprintf(_T("Frame rate\t%.2f\n"), dFrameRate);

    TCHAR* sMemType = m_bd3dAlloc ? _T("d3d") : _T("system");
    _tprintf(_T("Memory type\t\t%s\n"), sMemType);

    mfxIMPL impl;
    m_mfxSession.QueryIMPL(&impl);

    TCHAR* sImpl = (MFX_IMPL_HARDWARE == impl) ? _T("hw") : _T("sw");
    _tprintf(_T("MediaSDK impl\t\t%s\n"), sImpl);

    mfxVersion ver;
    m_mfxSession.QueryVersion(&ver);
    _tprintf(_T("MediaSDK version\t%d.%d\n"), ver.Major, ver.Minor);

    _tprintf(_T("\n"));

    return;
}