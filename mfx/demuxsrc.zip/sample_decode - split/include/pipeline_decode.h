//* ////////////////////////////////////////////////////////////////////////////// */
//*
//
//              INTEL CORPORATION PROPRIETARY INFORMATION
//  This software is supplied under the terms of a license  agreement or
//  nondisclosure agreement with Intel Corporation and may not be copied
//  or disclosed except in  accordance  with the terms of that agreement.
//        Copyright (c) 2005-2010 Intel Corporation. All Rights Reserved.
//
//
//*/
   
#ifndef __PIPELINE_DECODE_H__
#define __PIPELINE_DECODE_H__

#define D3D_SURFACES_SUPPORT

#ifdef D3D_SURFACES_SUPPORT
#pragma warning(disable : 4201)
#include <d3d9.h>
#include <dxva2api.h>
#endif

#include "sample_defs.h"
#include "sample_utils.h"
#include "base_allocator.h"

#include "mfxvideo.h"
#include "mfxvideo++.h"

struct sInputParams
{
    mfxU32 videoType;
    bool   bd3dAlloc; // true - frames in video memory (d3d surfaces),  false - in system memory
    bool   bUseHWLib; // true if application wants to use HW mfx library

    TCHAR  strSrcFile[MAX_FILENAME_LEN];
    TCHAR  strDstFile[MAX_FILENAME_LEN];

	bool   bSplit;
};

class CDecodingPipeline
{
public:

    CDecodingPipeline();
    virtual ~CDecodingPipeline();

    virtual mfxStatus Init(sInputParams *pParams);
    virtual mfxStatus RunDecoding();
    virtual void Close();
    virtual mfxStatus ResetDecoder();
    virtual mfxStatus ResetDevice();

protected:
    CSmplYUVWriter          m_FileWriter;
    CSmplBitstreamReader *m_pFileReader;
    mfxU32              m_nFrameIndex; // index of processed frame
    mfxBitstream        m_mfxBS; // contains encoded data

    MFXVideoSession     m_mfxSession;
    MFXVideoDECODE*     m_pmfxDEC;
    mfxVideoParam       m_mfxVideoParams; 
    
    MFXFrameAllocator*      m_pMFXAllocator; 
    mfxAllocatorParams*     m_pmfxAllocatorParams;
    bool                    m_bd3dAlloc; // use d3d surfaces
    bool                    m_bExternalAlloc; // use memory allocator as external for Media SDK
    mfxFrameSurface1*       m_pmfxSurfaces; // frames array
    mfxFrameAllocResponse   m_mfxResponse;  // memory allocation response for decoder  

#ifdef D3D_SURFACES_SUPPORT
    IDirect3D9*              m_pd3d;
    IDirect3DDeviceManager9* m_pd3dDeviceManager; 
    IDirect3DDevice9*        m_pd3dDevice;
    UINT                     m_resetToken;
#endif  

    virtual mfxStatus InitMfxParams();
    virtual mfxStatus CreateAllocator();
    virtual mfxStatus CreateDeviceManager(); 
    virtual mfxStatus AllocFrames();
    virtual void DeleteFrames();         
    virtual void DeleteAllocator();    
    virtual void  PrintInfo();
};

#endif // __PIPELINE_DECODE_H__ 